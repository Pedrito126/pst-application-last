/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        ittre: {
          green: '#1B4332',
          burgundy: '#9B2242',
          yellow: '#FFD700',
        },
      },
    },
  },
  plugins: [
    require('@tailwindcss/forms'),
  ],
};