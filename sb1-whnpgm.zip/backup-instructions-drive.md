# Instructions de sauvegarde sur Google Drive

1. Structure des dossiers sur Google Drive :
   ```
   PST-Application/
   ├── source/
   │   ├── src/
   │   ├── public/
   │   └── config/
   ├── build/
   │   └── dist/
   └── documentation/
   ```

2. Fichiers à sauvegarder :

   A. Dossier source/ :
   - Tout le contenu du dossier src/
   - package.json
   - vite.config.ts
   - tsconfig.json
   - tailwind.config.js
   - index.html
   - Autres fichiers de configuration

   B. Dossier build/ :
   - Le dossier dist/ complet généré par npm run build

   C. Dossier documentation/ :
   - Manuel utilisateur
   - Instructions de déploiement
   - Schéma de la base de données
   - Notes techniques

3. Bonnes pratiques :
   - Créez un nouveau dossier daté pour chaque sauvegarde
   - Utilisez la convention de nommage : PST-Application-YYYYMMDD
   - Activez la synchronisation hors ligne pour les fichiers importants
   - Partagez le dossier avec les personnes concernées en lecture seule

4. Maintenance :
   - Conservez les 3 dernières sauvegardes
   - Vérifiez l'intégrité des fichiers après chaque upload
   - Documentez les changements majeurs dans un fichier changelog.md