import React, { useState } from 'react';
import { FileText, Loader } from 'lucide-react';
import { useProjetStore } from '../../store/projetStore';
import { useAuditStore } from '../../store/auditStore';
import { formatDate, formatMontant } from '../../utils/formatters';

export function RapportIA() {
  const [loading, setLoading] = useState(false);
  const [rapport, setRapport] = useState<string | null>(null);
  const [dateDebut, setDateDebut] = useState('');
  const projets = useProjetStore((state) => state.projets);
  const getLogs = useAuditStore((state) => state.getLogs);

  const genererRapport = async () => {
    setLoading(true);
    try {
      // Analyse des données
      const projetsFiltres = dateDebut ? 
        projets.filter(p => new Date(p.dateCreation) >= new Date(dateDebut)) :
        projets;

      const stats = {
        total: projetsFiltres.length,
        enCours: projetsFiltres.filter(p => p.etat === 'EN_COURS').length,
        termine: projetsFiltres.filter(p => p.etat === 'TERMINE').length,
        bloque: projetsFiltres.filter(p => p.etat === 'BLOQUE').length,
        budgetTotal: projetsFiltres.reduce((sum, p) => sum + p.budgetActualise, 0),
        subsideTotal: projetsFiltres.reduce((sum, p) => sum + (p.subside.actif ? p.subside.montant : 0), 0),
      };

      // Génération du rapport
      const rapport = `
RAPPORT D'ANALYSE DU PST
Date de génération: ${formatDate(new Date().toISOString())}
${dateDebut ? `Période analysée: depuis le ${formatDate(dateDebut)}` : 'Analyse complète'}

SYNTHÈSE GÉNÉRALE
----------------
Nombre total de projets: ${stats.total}
Projets en cours: ${stats.enCours} (${Math.round((stats.enCours / stats.total) * 100)}%)
Projets terminés: ${stats.termine} (${Math.round((stats.termine / stats.total) * 100)}%)
Projets bloqués: ${stats.bloque} (${Math.round((stats.bloque / stats.total) * 100)}%)

ANALYSE FINANCIÈRE
----------------
Budget total engagé: ${formatMontant(stats.budgetTotal)}
Total des subsides: ${formatMontant(stats.subsideTotal)}
Taux de couverture: ${Math.round((stats.subsideTotal / stats.budgetTotal) * 100)}%

RECOMMANDATIONS
--------------
${stats.bloque > 0 ? `⚠️ Attention: ${stats.bloque} projet(s) bloqué(s) nécessitent une intervention` : '✅ Aucun projet bloqué'}
${stats.subsideTotal / stats.budgetTotal < 0.3 ? '⚠️ Le taux de couverture par les subsides est faible' : '✅ Bon taux de couverture par les subsides'}
${stats.termine / stats.total < 0.2 ? '⚠️ Le taux de réalisation est faible' : '✅ Bon taux de réalisation'}

PROJETS PRIORITAIRES À SUIVRE
---------------------------
${projetsFiltres
  .filter(p => p.etat === 'BLOQUE' || (p.budgetActualise > 100000 && p.etat !== 'TERMINE'))
  .map(p => `- ${p.titre} (${p.etat.replace('_', ' ')}) - Budget: ${formatMontant(p.budgetActualise)}`)
  .join('\n')}
`;

      setRapport(rapport);
    } catch (error) {
      console.error('Erreur lors de la génération du rapport:', error);
      setRapport('Erreur lors de la génération du rapport');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <h2 className="text-xl font-semibold mb-4">Rapport IA</h2>
      
      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Date de début d'analyse
        </label>
        <input
          type="date"
          value={dateDebut}
          onChange={(e) => setDateDebut(e.target.value)}
          className="w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
        />
      </div>

      <button
        onClick={genererRapport}
        disabled={loading}
        className="w-full flex justify-center items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-[#1B4332] hover:bg-[#9B2242] disabled:bg-[#1B4332]/50"
      >
        {loading ? (
          <>
            <Loader className="animate-spin h-5 w-5 mr-2" />
            Génération en cours...
          </>
        ) : (
          <>
            <FileText className="h-5 w-5 mr-2" />
            Générer le rapport
          </>
        )}
      </button>

      {rapport && (
        <div className="mt-6">
          <pre className="whitespace-pre-wrap bg-gray-50 p-4 rounded-md text-sm font-mono">
            {rapport}
          </pre>
        </div>
      )}
    </div>
  );
}