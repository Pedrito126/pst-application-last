import React, { useState } from 'react';
import { useAuditStore } from '../../store/auditStore';
import { formatDate } from '../../utils/formatters';

export function JournalAudit() {
  const [dateDebut, setDateDebut] = useState<string>('');
  const [dateFin, setDateFin] = useState<string>('');
  const [typeAction, setTypeAction] = useState<string>('');

  const logs = useAuditStore((state) => state.getLogs({
    startDate: dateDebut ? new Date(dateDebut) : undefined,
    endDate: dateFin ? new Date(dateFin) : undefined,
    actionType: typeAction as any || undefined,
  }));

  const getActionLabel = (action: string) => {
    const labels: Record<string, string> = {
      CREATION_PROJET: 'Création de projet',
      MODIFICATION_PROJET: 'Modification de projet',
      SUPPRESSION_PROJET: 'Suppression de projet',
      CONNEXION: 'Connexion',
      DECONNEXION: 'Déconnexion',
      CREATION_COMPTE: 'Création de compte',
    };
    return labels[action] || action;
  };

  return (
    <div className="space-y-4">
      <div className="bg-white p-4 rounded-lg shadow">
        <h2 className="text-lg font-medium mb-4">Filtres</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Date de début
            </label>
            <input
              type="date"
              value={dateDebut}
              onChange={(e) => setDateDebut(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Date de fin
            </label>
            <input
              type="date"
              value={dateFin}
              onChange={(e) => setDateFin(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Type d'action
            </label>
            <select
              value={typeAction}
              onChange={(e) => setTypeAction(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="">Toutes les actions</option>
              <option value="CREATION_PROJET">Création de projet</option>
              <option value="MODIFICATION_PROJET">Modification de projet</option>
              <option value="SUPPRESSION_PROJET">Suppression de projet</option>
              <option value="CONNEXION">Connexion</option>
              <option value="DECONNEXION">Déconnexion</option>
              <option value="CREATION_COMPTE">Création de compte</option>
            </select>
          </div>
        </div>
      </div>

      <div className="bg-white shadow rounded-lg overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Date
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Utilisateur
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Rôle
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Action
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Détails
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {logs.map((log) => (
              <tr key={log.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {formatDate(log.timestamp)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {log.userName}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {log.userRole}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {getActionLabel(log.actionType)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {log.details.projetTitre && (
                    <span>Projet: {log.details.projetTitre}</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}