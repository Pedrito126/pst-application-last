import React from 'react';
import { History, ArrowLeft, ArrowRight } from 'lucide-react';
import { formatDate } from '../../utils/formatters';
import { VersionProjet } from '../../types/projet';

interface HistoriqueVersionsProps {
  versions: VersionProjet[];
  onRestore?: (version: number) => void;
}

export function HistoriqueVersions({ versions, onRestore }: HistoriqueVersionsProps) {
  const [selectedVersion, setSelectedVersion] = React.useState<number | null>(null);
  const [compareVersion, setCompareVersion] = React.useState<number | null>(null);

  const sortedVersions = [...versions].sort((a, b) => b.version - a.version);

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-medium flex items-center">
          <History className="h-5 w-5 mr-2" />
          Historique des versions
        </h3>
        {selectedVersion && onRestore && (
          <button
            onClick={() => onRestore(selectedVersion)}
            className="px-4 py-2 text-sm font-medium text-white bg-[#1B4332] rounded-md hover:bg-[#9B2242]"
          >
            Restaurer cette version
          </button>
        )}
      </div>

      <div className="space-y-4">
        {sortedVersions.map((version) => (
          <div
            key={version.version}
            className={`p-4 rounded-lg border ${
              selectedVersion === version.version
                ? 'border-[#1B4332] bg-[#1B4332]/5'
                : compareVersion === version.version
                ? 'border-[#9B2242] bg-[#9B2242]/5'
                : 'border-gray-200 hover:bg-gray-50'
            } cursor-pointer`}
            onClick={() => {
              if (selectedVersion === version.version) {
                setSelectedVersion(null);
              } else if (compareVersion === version.version) {
                setCompareVersion(null);
              } else if (!selectedVersion) {
                setSelectedVersion(version.version);
              } else {
                setCompareVersion(version.version);
              }
            }}
          >
            <div className="flex justify-between items-start">
              <div>
                <h4 className="font-medium text-gray-900">
                  Version {version.version}
                </h4>
                <p className="text-sm text-gray-500">
                  {formatDate(version.date)} par {version.auteur}
                </p>
              </div>
              {version.commentaire && (
                <span className="text-sm text-gray-600 italic">
                  "{version.commentaire}"
                </span>
              )}
            </div>
            {version.modifications.length > 0 && (
              <ul className="mt-2 space-y-1">
                {version.modifications.map((modification, index) => (
                  <li key={index} className="text-sm text-gray-600">
                    • {modification}
                  </li>
                ))}
              </ul>
            )}
          </div>
        ))}
      </div>

      {selectedVersion && compareVersion && (
        <div className="mt-6 p-4 rounded-lg bg-gray-50 border border-gray-200">
          <h4 className="font-medium text-gray-900 mb-2">Comparaison des versions</h4>
          <div className="flex items-center justify-between text-sm text-gray-600">
            <div>
              Version {compareVersion}
              <ArrowRight className="inline-block h-4 w-4 mx-2" />
              Version {selectedVersion}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}