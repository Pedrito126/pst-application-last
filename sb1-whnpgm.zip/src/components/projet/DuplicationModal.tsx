import React, { useState } from 'react';
import { useProjetStore } from '../../store/projetStore';
import { useNotifications } from '../notifications/NotificationsProvider';
import { X } from 'lucide-react';

interface DuplicationModalProps {
  projetId: string;
  onClose: () => void;
}

export function DuplicationModal({ projetId, onClose }: DuplicationModalProps) {
  const [conserverLiens, setConserverLiens] = useState(true);
  const [conserverAnnexes, setConserverAnnexes] = useState(true);
  const { projets, dupliquerProjet } = useProjetStore();
  const { addNotification } = useNotifications();

  const projet = projets.find(p => p.id === projetId);
  if (!projet) return null;

  const handleDuplication = () => {
    try {
      dupliquerProjet(projetId, {
        conserverLiens,
        conserverAnnexes,
      });
      addNotification('success', 'Projet dupliqué avec succès');
      onClose();
    } catch (error) {
      addNotification('error', 'Erreur lors de la duplication du projet');
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-md w-full p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-medium">Dupliquer le projet</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-500"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <p className="text-gray-600 mb-4">
          Vous êtes sur le point de dupliquer le projet "{projet.titre}".
        </p>

        <div className="space-y-4">
          <label className="flex items-center">
            <input
              type="checkbox"
              checked={conserverLiens}
              onChange={(e) => setConserverLiens(e.target.checked)}
              className="rounded border-gray-300 text-[#1B4332] focus:ring-[#1B4332]"
            />
            <span className="ml-2 text-gray-700">
              Conserver les liens avec les autres projets
            </span>
          </label>

          <label className="flex items-center">
            <input
              type="checkbox"
              checked={conserverAnnexes}
              onChange={(e) => setConserverAnnexes(e.target.checked)}
              className="rounded border-gray-300 text-[#1B4332] focus:ring-[#1B4332]"
            />
            <span className="ml-2 text-gray-700">
              Copier les annexes
            </span>
          </label>
        </div>

        <div className="mt-6 flex justify-end space-x-3">
          <button
            onClick={onClose}
            className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
          >
            Annuler
          </button>
          <button
            onClick={handleDuplication}
            className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-[#1B4332] hover:bg-[#9B2242]"
          >
            Dupliquer
          </button>
        </div>
      </div>
    </div>
  );
}