import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Filter } from 'lucide-react';
import { useProjetStore } from '../../store/projetStore';
import { ODD } from '../../config/auth';

export function FiltresAvances() {
  const { setFiltres } = useProjetStore();
  const { register, handleSubmit } = useForm();
  const [selectedODD, setSelectedODD] = useState<number | null>(null);

  const onSubmit = (data) => {
    setFiltres({
      etat: data.etat || undefined,
      volet: data.volet || undefined,
      priorite: data.priorite || undefined,
      refODD: selectedODD || undefined,
      periode: data.dateDebut || data.dateFin ? {
        debut: data.dateDebut ? new Date(data.dateDebut) : undefined,
        fin: data.dateFin ? new Date(data.dateFin) : undefined,
      } : undefined,
      recherche: data.recherche || undefined,
    });
  };

  const handleODDChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = parseInt(e.target.value);
    setSelectedODD(value || null);
  };

  const selectedODDInfo = selectedODD ? ODD.find(o => o.id === selectedODD) : null;

  return (
    <div className="bg-white shadow rounded-lg p-6 mb-6">
      <div className="flex items-center mb-4">
        <Filter className="h-5 w-5 text-gray-400 mr-2" />
        <h2 className="text-lg font-medium">Filtres avancés</h2>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">État</label>
            <select
              {...register('etat')}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
            >
              <option value="">Tous</option>
              <option value="NON_DEMARRE">Non démarré</option>
              <option value="EN_COURS">En cours</option>
              <option value="TERMINE">Terminé</option>
              <option value="BLOQUE">Bloqué</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Volet</label>
            <select
              {...register('volet')}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
            >
              <option value="">Tous</option>
              <option value="INTERNE">Interne</option>
              <option value="EXTERNE">Externe</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Priorité</label>
            <select
              {...register('priorite')}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
            >
              <option value="">Toutes</option>
              <option value="P1">P1 (2024-2026)</option>
              <option value="P2">P2 (2026-2028)</option>
              <option value="P3">P3 (2028-2030)</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Date de début</label>
            <input
              type="date"
              {...register('dateDebut')}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Date de fin</label>
            <input
              type="date"
              {...register('dateFin')}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            Objectif de Développement Durable
          </label>
          <select
            value={selectedODD || ''}
            onChange={handleODDChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
          >
            <option value="">Tous les ODD</option>
            {ODD.map((odd) => (
              <option 
                key={odd.id} 
                value={odd.id}
                style={{ backgroundColor: odd.couleur + '20' }}
              >
                ODD {odd.id.toString().padStart(2, '0')} - {odd.titre}
              </option>
            ))}
          </select>

          {selectedODDInfo && (
            <div 
              className="mt-2 p-3 rounded-md"
              style={{ 
                backgroundColor: `${selectedODDInfo.couleur}20`,
                borderLeft: `4px solid ${selectedODDInfo.couleur}`
              }}
            >
              <p className="text-sm" style={{ color: selectedODDInfo.couleur }}>
                {selectedODDInfo.description}
              </p>
            </div>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Recherche</label>
          <input
            type="text"
            {...register('recherche')}
            placeholder="Rechercher par titre, description..."
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
          />
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-[#1B4332] hover:bg-[#9B2242]"
          >
            Appliquer les filtres
          </button>
        </div>
      </form>
    </div>
  );
}