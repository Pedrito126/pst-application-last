import React, { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Paperclip, X, Link as LinkIcon, FileText, Image, FolderPlus, Tag } from 'lucide-react';
import { useAnnexeStore } from '../../store/annexeStore';
import { formatDate } from '../../utils/formatters';
import { PreviewAnnexe } from '../annexe/PreviewAnnexe';
import { TypeAnnexe, CategorieAnnexe } from '../../types/annexe';

interface GestionAnnexesProps {
  projetId: string;
  isNewProject?: boolean;
}

export function GestionAnnexes({ projetId, isNewProject }: GestionAnnexesProps) {
  const { ajouterAnnexe, supprimerAnnexe, getAnnexesProjet } = useAnnexeStore();
  const [selectedAnnexe, setSelectedAnnexe] = React.useState<string | null>(null);
  const [showAddFolder, setShowAddFolder] = React.useState(false);
  const [newFolder, setNewFolder] = React.useState('');
  const [selectedCategorie, setSelectedCategorie] = React.useState<CategorieAnnexe>('autre');
  const [tags, setTags] = React.useState<string[]>([]);
  const [newTag, setNewTag] = React.useState('');

  const annexes = getAnnexesProjet(projetId);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    acceptedFiles.forEach((file) => {
      const reader = new FileReader();
      reader.onload = () => {
        const type: TypeAnnexe = file.type.startsWith('image/')
          ? 'image'
          : file.type === 'application/pdf'
          ? 'pdf'
          : file.type.includes('officedocument')
          ? 'office'
          : 'document';

        const annexe = {
          id: crypto.randomUUID(),
          projetId,
          nom: file.name,
          type,
          url: URL.createObjectURL(file),
          dateAjout: new Date().toISOString(),
          taille: file.size,
          categorie: selectedCategorie,
          tags,
          version: 1,
          historique: [],
        };
        ajouterAnnexe(annexe);
      };
      reader.readAsArrayBuffer(file);
    });
  }, [projetId, ajouterAnnexe, selectedCategorie, tags]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.png', '.jpg', '.jpeg', '.gif'],
      'application/pdf': ['.pdf'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
    },
  });

  const ajouterLien = () => {
    const url = window.prompt('Entrez l\'URL du lien :');
    if (url) {
      const annexe = {
        id: crypto.randomUUID(),
        projetId,
        nom: url,
        type: 'lien' as TypeAnnexe,
        url,
        dateAjout: new Date().toISOString(),
        categorie: selectedCategorie,
        tags,
        version: 1,
        historique: [],
      };
      ajouterAnnexe(annexe);
    }
  };

  const handleAddTag = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && newTag.trim()) {
      e.preventDefault();
      setTags([...tags, newTag.trim()]);
      setNewTag('');
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };

  const handleAddFolder = () => {
    if (newFolder.trim()) {
      // Logique d'ajout de dossier
      setShowAddFolder(false);
      setNewFolder('');
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-medium">Documents et annexes</h3>
        <div className="flex space-x-2">
          <button
            onClick={() => setShowAddFolder(true)}
            className="inline-flex items-center px-3 py-1.5 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
          >
            <FolderPlus className="h-4 w-4 mr-2" />
            Nouveau dossier
          </button>
          <button
            onClick={ajouterLien}
            className="inline-flex items-center px-3 py-1.5 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
          >
            <LinkIcon className="h-4 w-4 mr-2" />
            Ajouter un lien
          </button>
        </div>
      </div>

      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Catégorie
        </label>
        <select
          value={selectedCategorie}
          onChange={(e) => setSelectedCategorie(e.target.value as CategorieAnnexe)}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
        >
          <option value="documentation">Documentation</option>
          <option value="technique">Technique</option>
          <option value="administratif">Administratif</option>
          <option value="financier">Financier</option>
          <option value="autre">Autre</option>
        </select>
      </div>

      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Tags
        </label>
        <div className="flex flex-wrap gap-2 mb-2">
          {tags.map(tag => (
            <span
              key={tag}
              className="inline-flex items-center px-2 py-1 rounded-full text-sm bg-gray-100"
            >
              {tag}
              <button
                onClick={() => handleRemoveTag(tag)}
                className="ml-1 text-gray-500 hover:text-gray-700"
              >
                <X className="h-3 w-3" />
              </button>
            </span>
          ))}
        </div>
        <input
          type="text"
          value={newTag}
          onChange={(e) => setNewTag(e.target.value)}
          onKeyPress={handleAddTag}
          placeholder="Ajouter un tag (Entrée pour valider)"
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
        />
      </div>

      <div
        {...getRootProps()}
        className={`border-2 border-dashed rounded-lg p-6 text-center ${
          isDragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
        }`}
      >
        <input {...getInputProps()} />
        <Paperclip className="h-8 w-8 mx-auto text-gray-400 mb-2" />
        <p className="text-sm text-gray-600">
          {isDragActive
            ? 'Déposez les fichiers ici...'
            : 'Glissez-déposez des fichiers ici, ou cliquez pour sélectionner'}
        </p>
        <p className="text-xs text-gray-500 mt-2">
          Formats acceptés : Images, PDF, Documents Word
        </p>
      </div>

      {annexes.length > 0 && (
        <div className="mt-4">
          <h4 className="text-sm font-medium text-gray-700 mb-2">
            Fichiers attachés ({annexes.length})
          </h4>
          <div className="divide-y divide-gray-200">
            {annexes.map((annexe) => (
              <div
                key={annexe.id}
                className="py-3 flex justify-between items-center hover:bg-gray-50"
              >
                <div className="flex items-center">
                  {annexe.type === 'image' && <Image className="h-5 w-5 text-blue-500" />}
                  {annexe.type === 'pdf' && <FileText className="h-5 w-5 text-red-500" />}
                  {annexe.type === 'office' && <FileText className="h-5 w-5 text-green-500" />}
                  {annexe.type === 'lien' && <LinkIcon className="h-5 w-5 text-purple-500" />}
                  <div className="ml-3">
                    <p className="text-sm font-medium text-gray-900">
                      {annexe.nom}
                    </p>
                    <p className="text-xs text-gray-500">
                      {formatDate(annexe.dateAjout)}
                      {annexe.taille && (
                        <span className="ml-2">
                          ({Math.round(annexe.taille / 1024)} Ko)
                        </span>
                      )}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setSelectedAnnexe(annexe.id)}
                    className="text-gray-400 hover:text-gray-500"
                  >
                    Aperçu
                  </button>
                  {annexe.type === 'lien' ? (
                    <a
                      href={annexe.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:text-blue-800"
                    >
                      Ouvrir
                    </a>
                  ) : (
                    <a
                      href={annexe.url}
                      download={annexe.nom}
                      className="text-blue-600 hover:text-blue-800"
                    >
                      Télécharger
                    </a>
                  )}
                  <button
                    onClick={() => supprimerAnnexe(projetId, annexe.id)}
                    className="text-red-600 hover:text-red-800"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {selectedAnnexe && (
        <PreviewAnnexe
          annexe={annexes.find(a => a.id === selectedAnnexe)!}
          onClose={() => setSelectedAnnexe(null)}
        />
      )}

      {showAddFolder && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h4 className="text-lg font-medium mb-4">Nouveau dossier</h4>
            <input
              type="text"
              value={newFolder}
              onChange={(e) => setNewFolder(e.target.value)}
              placeholder="Nom du dossier"
              className="w-full px-3 py-2 border rounded-md"
            />
            <div className="flex justify-end mt-4 space-x-2">
              <button
                onClick={() => setShowAddFolder(false)}
                className="px-4 py-2 text-gray-600 hover:text-gray-800"
              >
                Annuler
              </button>
              <button
                onClick={handleAddFolder}
                className="px-4 py-2 bg-[#1B4332] text-white rounded-md hover:bg-[#9B2242]"
              >
                Créer
              </button>
            </div>
          </div>
        </div>
      )}

      {isNewProject && (
        <p className="text-sm text-gray-500 mt-4">
          Les fichiers seront définitivement attachés au projet lors de sa création.
        </p>
      )}
    </div>
  );
}