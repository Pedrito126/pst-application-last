import React, { useState } from 'react';
import { Download, FileText, FileSpreadsheet } from 'lucide-react';
import { useProjetStore } from '../../store/projetStore';
import { exportProjetsPDF } from '../../utils/pdfExport';
import { exportProjetsDocx } from '../../utils/docxExport';
import { useNotifications } from '../notifications/NotificationsProvider';

export function ExportPDF() {
  const [showMenu, setShowMenu] = useState(false);
  const { projets, filtres } = useProjetStore();
  const { addNotification } = useNotifications();

  const handleExportPDF = () => {
    try {
      const doc = exportProjetsPDF(projets, filtres);
      doc.save('projets-pst.pdf');
      addNotification('success', 'Export PDF réussi');
    } catch (error) {
      console.error('Erreur lors de la génération du PDF:', error);
      addNotification('error', 'Erreur lors de l\'export PDF');
    }
  };

  const handleExportDOCX = async () => {
    try {
      await exportProjetsDocx(projets, filtres);
      addNotification('success', 'Export DOCX réussi');
    } catch (error) {
      console.error('Erreur lors de la génération du DOCX:', error);
      addNotification('error', 'Erreur lors de l\'export DOCX');
    }
  };

  return (
    <div className="relative">
      <button
        onClick={() => setShowMenu(!showMenu)}
        className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-[#1B4332] hover:bg-[#9B2242]"
      >
        <Download className="h-5 w-5 mr-2" />
        Exporter
      </button>

      {showMenu && (
        <div className="absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5">
          <div className="py-1">
            <button
              onClick={() => {
                handleExportPDF();
                setShowMenu(false);
              }}
              className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center"
            >
              <FileText className="h-4 w-4 mr-2" />
              Exporter en PDF
            </button>
            <button
              onClick={() => {
                handleExportDOCX();
                setShowMenu(false);
              }}
              className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center"
            >
              <FileSpreadsheet className="h-4 w-4 mr-2" />
              Exporter en DOCX
            </button>
          </div>
        </div>
      )}
    </div>
  );
}