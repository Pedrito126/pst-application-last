import React, { useState } from 'react';
import { AlertTriangle, Plus, Edit2, Trash2 } from 'lucide-react';
import { useDashboardStore } from '../../store/dashboardStore';
import { Risque } from '../../types/dashboard';
import { formatDate } from '../../utils/formatters';

interface GestionRisquesProps {
  projetId: string;
}

export function GestionRisques({ projetId }: GestionRisquesProps) {
  const [showForm, setShowForm] = useState(false);
  const [editingRisque, setEditingRisque] = useState<Risque | null>(null);
  const { risques, addRisque, updateRisque, deleteRisque } = useDashboardStore();

  const projetRisques = risques.filter(r => r.projetId === projetId);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const formData = new FormData(form);

    const risqueData = {
      projetId,
      description: formData.get('description') as string,
      probabilite: parseInt(formData.get('probabilite') as string) as 1 | 2 | 3 | 4 | 5,
      impact: parseInt(formData.get('impact') as string) as 1 | 2 | 3 | 4 | 5,
      statut: formData.get('statut') as 'identifie' | 'en-cours' | 'mitige' | 'realise',
      planMitigation: formData.get('planMitigation') as string,
      responsable: formData.get('responsable') as string,
    };

    if (editingRisque) {
      updateRisque(editingRisque.id, risqueData);
    } else {
      addRisque(risqueData);
    }

    setShowForm(false);
    setEditingRisque(null);
  };

  const getScoreClass = (score: number) => {
    if (score >= 16) return 'bg-red-100 text-red-800';
    if (score >= 9) return 'bg-yellow-100 text-yellow-800';
    return 'bg-green-100 text-green-800';
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium flex items-center">
          <AlertTriangle className="h-5 w-5 mr-2" />
          Gestion des risques
        </h3>
        <button
          onClick={() => setShowForm(true)}
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-[#1B4332] hover:bg-[#9B2242]"
        >
          <Plus className="h-4 w-4 mr-2" />
          Nouveau risque
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="space-y-4 bg-gray-50 p-4 rounded-lg">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Description
            </label>
            <textarea
              name="description"
              defaultValue={editingRisque?.description}
              required
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
              rows={3}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Probabilité
              </label>
              <select
                name="probabilite"
                defaultValue={editingRisque?.probabilite || "3"}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
              >
                <option value="1">Très faible</option>
                <option value="2">Faible</option>
                <option value="3">Moyenne</option>
                <option value="4">Élevée</option>
                <option value="5">Très élevée</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Impact
              </label>
              <select
                name="impact"
                defaultValue={editingRisque?.impact || "3"}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
              >
                <option value="1">Très faible</option>
                <option value="2">Faible</option>
                <option value="3">Moyen</option>
                <option value="4">Élevé</option>
                <option value="5">Très élevé</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Plan de mitigation
            </label>
            <textarea
              name="planMitigation"
              defaultValue={editingRisque?.planMitigation}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
              rows={2}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Statut
              </label>
              <select
                name="statut"
                defaultValue={editingRisque?.statut || "identifie"}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
              >
                <option value="identifie">Identifié</option>
                <option value="en-cours">En cours</option>
                <option value="mitige">Mitigé</option>
                <option value="realise">Réalisé</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Responsable
              </label>
              <input
                type="text"
                name="responsable"
                defaultValue={editingRisque?.responsable}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
              />
            </div>
          </div>

          <div className="flex justify-end space-x-3">
            <button
              type="button"
              onClick={() => {
                setShowForm(false);
                setEditingRisque(null);
              }}
              className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-[#1B4332] hover:bg-[#9B2242]"
            >
              {editingRisque ? 'Mettre à jour' : 'Ajouter'}
            </button>
          </div>
        </form>
      )}

      <div className="space-y-4">
        {projetRisques.map((risque) => {
          const score = risque.probabilite * risque.impact;
          return (
            <div
              key={risque.id}
              className="bg-white p-4 rounded-lg border border-gray-200"
            >
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center space-x-2">
                    <h4 className="font-medium text-gray-900">
                      {risque.description}
                    </h4>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getScoreClass(score)}`}>
                      Score: {score}/25
                    </span>
                  </div>
                  <p className="mt-1 text-sm text-gray-500">
                    Responsable: {risque.responsable}
                  </p>
                  {risque.planMitigation && (
                    <p className="mt-2 text-sm text-gray-600">
                      Plan de mitigation: {risque.planMitigation}
                    </p>
                  )}
                  <div className="mt-2 flex items-center space-x-4 text-sm text-gray-500">
                    <span>Probabilité: {risque.probabilite}/5</span>
                    <span>Impact: {risque.impact}/5</span>
                    <span>Statut: {risque.statut}</span>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={() => {
                      setEditingRisque(risque);
                      setShowForm(true);
                    }}
                    className="text-gray-400 hover:text-gray-500"
                  >
                    <Edit2 className="h-5 w-5" />
                  </button>
                  <button
                    onClick={() => deleteRisque(risque.id)}
                    className="text-gray-400 hover:text-red-500"
                  >
                    <Trash2 className="h-5 w-5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}