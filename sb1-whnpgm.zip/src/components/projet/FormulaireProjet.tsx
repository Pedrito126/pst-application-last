import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useProjetStore } from '../../store/projetStore';
import { useNotifications } from '../notifications/NotificationsProvider';
import { GestionAnnexes } from './GestionAnnexes';
import { generateProjetReference } from '../../utils/codeGenerator';

const projetSchema = z.object({
  titre: z.string().min(1, 'Le titre est requis'),
  description: z.string().min(1, 'La description est requise'),
  etat: z.enum(['BROUILLON', 'NON_DEMARRE', 'EN_COURS', 'TERMINE', 'BLOQUE']),
  volet: z.enum(['INTERNE', 'EXTERNE']),
  priorite: z.enum(['P1', 'P2', 'P3']),
  refDPC: z.string().optional(),
  budgetActualise: z.number().min(0, 'Le budget doit être positif'),
  chefProjet: z.string(),
  agentPartenaire: z.string(),
  partenaireExterne: z.string(),
  echevinReferent: z.string(),
  conditionsContraintes: z.string(),
  realisation: z.string().optional(),
  objectifStrategique: z.string(),
  objectifOperationnel: z.string(),
});

type FormData = z.infer<typeof projetSchema>;

interface FormulaireProjetProps {
  projetId?: string;
  onSuccess: () => void;
}

export function FormulaireProjet({ projetId, onSuccess }: FormulaireProjetProps) {
  const { projets, ajouterProjet, modifierProjet } = useProjetStore();
  const { addNotification } = useNotifications();

  const projetExistant = projetId ? projets.find(p => p.id === projetId) : undefined;

  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
  } = useForm<FormData>({
    resolver: zodResolver(projetSchema),
    defaultValues: projetExistant || {
      etat: 'BROUILLON',
      budgetActualise: 0,
    },
  });

  const onSubmit = async (data: FormData) => {
    try {
      const reference = projetExistant?.reference || generateProjetReference(
        data.volet,
        data.objectifStrategique,
        data.objectifOperationnel,
        projets.map(p => p.reference)
      );

      const projetData = {
        ...data,
        id: projetId || crypto.randomUUID(),
        reference,
        dateCreation: projetExistant?.dateCreation || new Date().toISOString(),
        dateMiseAJour: new Date().toISOString(),
        version: (projetExistant?.version || 0) + 1,
        historique: [
          ...(projetExistant?.historique || []),
          {
            version: (projetExistant?.version || 0) + 1,
            date: new Date().toISOString(),
            auteur: 'Utilisateur actuel', // À remplacer par l'utilisateur connecté
            modifications: ['Mise à jour du projet'],
          }
        ],
        projetsLies: projetExistant?.projetsLies || [],
      };

      if (projetId) {
        modifierProjet(projetId, projetData);
        addNotification('success', 'Projet modifié avec succès');
      } else {
        ajouterProjet(projetData);
        addNotification('success', 'Projet créé avec succès');
      }
      onSuccess();
    } catch (error) {
      addNotification('error', 'Erreur lors de la sauvegarde du projet');
    }
  };

  return (
    <div className="space-y-6">
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Titre
            </label>
            <input
              type="text"
              {...register('titre')}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
            />
            {errors.titre && (
              <p className="mt-1 text-sm text-red-600">{errors.titre.message}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              État
            </label>
            <select
              {...register('etat')}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
            >
              <option value="BROUILLON">Brouillon</option>
              <option value="NON_DEMARRE">Non démarré</option>
              <option value="EN_COURS">En cours</option>
              <option value="TERMINE">Terminé</option>
              <option value="BLOQUE">Bloqué</option>
            </select>
            {errors.etat && (
              <p className="mt-1 text-sm text-red-600">{errors.etat.message}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Volet
            </label>
            <select
              {...register('volet')}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
            >
              <option value="INTERNE">Interne</option>
              <option value="EXTERNE">Externe</option>
            </select>
            {errors.volet && (
              <p className="mt-1 text-sm text-red-600">{errors.volet.message}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Priorité
            </label>
            <select
              {...register('priorite')}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
            >
              <option value="P1">P1 (2024-2026)</option>
              <option value="P2">P2 (2026-2028)</option>
              <option value="P3">P3 (2028-2030)</option>
            </select>
            {errors.priorite && (
              <p className="mt-1 text-sm text-red-600">{errors.priorite.message}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Référence DPC (optionnel)
            </label>
            <input
              type="text"
              {...register('refDPC')}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Budget actualisé
            </label>
            <input
              type="number"
              {...register('budgetActualise', { valueAsNumber: true })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
            />
            {errors.budgetActualise && (
              <p className="mt-1 text-sm text-red-600">{errors.budgetActualise.message}</p>
            )}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            Description
          </label>
          <textarea
            {...register('description')}
            rows={4}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
          />
          {errors.description && (
            <p className="mt-1 text-sm text-red-600">{errors.description.message}</p>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Chef(s) de projet
            </label>
            <input
              type="text"
              {...register('chefProjet')}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
              placeholder="Noms séparés par des virgules"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Agent(s) partenaire(s)
            </label>
            <input
              type="text"
              {...register('agentPartenaire')}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
              placeholder="Noms séparés par des virgules"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Partenaire(s) externe(s)
            </label>
            <input
              type="text"
              {...register('partenaireExterne')}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
              placeholder="Noms séparés par des virgules"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Échevin(s) référent(s)
            </label>
            <input
              type="text"
              {...register('echevinReferent')}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
              placeholder="Noms séparés par des virgules"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            Conditions et contraintes
          </label>
          <textarea
            {...register('conditionsContraintes')}
            rows={3}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            Réalisation
          </label>
          <textarea
            {...register('realisation')}
            rows={3}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
          />
        </div>

        <div className="flex justify-end space-x-3">
          <button
            type="submit"
            className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-[#1B4332] hover:bg-[#9B2242]"
          >
            {projetId ? 'Enregistrer' : 'Créer'}
          </button>
        </div>
      </form>

      <div className="mt-8 pt-8 border-t border-gray-200">
        <h3 className="text-lg font-medium mb-4">Documents et annexes</h3>
        <GestionAnnexes 
          projetId={projetId || 'temp-' + crypto.randomUUID()} 
          isNewProject={!projetId}
        />
      </div>
    </div>
  );
}