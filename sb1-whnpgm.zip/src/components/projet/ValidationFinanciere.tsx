import React, { useState } from 'react';
import { CheckCircle, XCircle } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import { useNotifications } from '../notifications/NotificationsProvider';
import { formatMontant } from '../../utils/formatters';

interface ValidationFinanciereProps {
  projetId: string;
  budget: number;
  subside: {
    actif: boolean;
    montant: number;
  };
}

export function ValidationFinanciere({ projetId, budget, subside }: ValidationFinanciereProps) {
  const [isValidated, setIsValidated] = useState(false);
  const [commentaire, setCommentaire] = useState('');
  const user = useAuthStore((state) => state.user);
  const { addNotification } = useNotifications();

  const canValidate = ['ADMIN', 'DF'].includes(user?.role || '');

  const handleValidation = (valide: boolean) => {
    if (!canValidate) return;

    setIsValidated(valide);
    addNotification(
      valide ? 'success' : 'warning',
      `Projet ${valide ? 'validé' : 'refusé'} par le service financier`
    );
  };

  if (!canValidate) return null;

  return (
    <div className="bg-white p-4 rounded-lg shadow mt-4">
      <h3 className="text-lg font-medium mb-4">Validation financière</h3>
      
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-gray-500">Budget</p>
            <p className="text-lg font-medium">{formatMontant(budget)}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Subside</p>
            <p className="text-lg font-medium">
              {subside.actif ? formatMontant(subside.montant) : 'Non applicable'}
            </p>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            Commentaire
          </label>
          <textarea
            value={commentaire}
            onChange={(e) => setCommentaire(e.target.value)}
            rows={3}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
        </div>

        <div className="flex space-x-4">
          <button
            onClick={() => handleValidation(true)}
            className="flex-1 inline-flex justify-center items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700"
          >
            <CheckCircle className="h-5 w-5 mr-2" />
            Valider
          </button>
          <button
            onClick={() => handleValidation(false)}
            className="flex-1 inline-flex justify-center items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700"
          >
            <XCircle className="h-5 w-5 mr-2" />
            Refuser
          </button>
        </div>
      </div>
    </div>
  );
}