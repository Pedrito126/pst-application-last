import React, { useState } from 'react';
import { MessageSquare, Reply, User, AtSign } from 'lucide-react';
import { useDashboardStore } from '../../store/dashboardStore';
import { useAuthStore } from '../../store/authStore';
import { formatDate } from '../../utils/formatters';

interface CommentaireProjetProps {
  projetId: string;
}

export function CommentaireProjet({ projetId }: CommentaireProjetProps) {
  const [message, setMessage] = useState('');
  const [replyTo, setReplyTo] = useState<string | null>(null);
  const { commentaires, addCommentaire, addReponse } = useDashboardStore();
  const { user } = useAuthStore();
  const [mentionSearch, setMentionSearch] = useState('');
  const [showMentions, setShowMentions] = useState(false);

  const projetCommentaires = commentaires[projetId] || [];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !message.trim()) return;

    if (replyTo) {
      addReponse(replyTo, {
        projetId,
        auteur: user.name,
        message: message.trim(),
        mentions: extractMentions(message),
      });
      setReplyTo(null);
    } else {
      addCommentaire({
        projetId,
        auteur: user.name,
        message: message.trim(),
        mentions: extractMentions(message),
      });
    }
    setMessage('');
  };

  const extractMentions = (text: string): string[] => {
    const mentions = text.match(/@(\w+)/g);
    return mentions ? mentions.map(m => m.slice(1)) : [];
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === '@') {
      setShowMentions(true);
      setMentionSearch('');
    }
  };

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-medium flex items-center">
        <MessageSquare className="h-5 w-5 mr-2" />
        Commentaires
      </h3>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={replyTo ? 'Écrire une réponse...' : 'Ajouter un commentaire...'}
            className="w-full rounded-lg border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
            rows={3}
          />
          {showMentions && (
            <div className="absolute z-10 w-64 bg-white border rounded-lg shadow-lg">
              {/* Liste des utilisateurs pour les mentions */}
            </div>
          )}
        </div>
        <div className="flex justify-end">
          {replyTo && (
            <button
              type="button"
              onClick={() => setReplyTo(null)}
              className="mr-2 px-4 py-2 text-gray-600 hover:text-gray-800"
            >
              Annuler
            </button>
          )}
          <button
            type="submit"
            className="px-4 py-2 bg-[#1B4332] text-white rounded-md hover:bg-[#9B2242]"
          >
            {replyTo ? 'Répondre' : 'Commenter'}
          </button>
        </div>
      </form>

      <div className="space-y-6">
        {projetCommentaires.map((commentaire) => (
          <div key={commentaire.id} className="bg-gray-50 rounded-lg p-4">
            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0">
                <User className="h-10 w-10 text-gray-400" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-medium text-gray-900">
                    {commentaire.auteur}
                  </h4>
                  <span className="text-sm text-gray-500">
                    {formatDate(commentaire.date)}
                  </span>
                </div>
                <p className="mt-1 text-sm text-gray-700">
                  {commentaire.message}
                </p>
                <button
                  onClick={() => setReplyTo(commentaire.id)}
                  className="mt-2 flex items-center text-sm text-gray-500 hover:text-gray-700"
                >
                  <Reply className="h-4 w-4 mr-1" />
                  Répondre
                </button>

                {commentaire.reponses.length > 0 && (
                  <div className="mt-4 space-y-4 pl-6 border-l-2 border-gray-200">
                    {commentaire.reponses.map((reponse) => (
                      <div key={reponse.id} className="bg-white rounded-lg p-3">
                        <div className="flex items-center justify-between">
                          <h5 className="text-sm font-medium text-gray-900">
                            {reponse.auteur}
                          </h5>
                          <span className="text-sm text-gray-500">
                            {formatDate(reponse.date)}
                          </span>
                        </div>
                        <p className="mt-1 text-sm text-gray-700">
                          {reponse.message}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}