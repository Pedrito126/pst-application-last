import React, { useState } from 'react';
import { Link as LinkIcon, Search, X } from 'lucide-react';
import { useProjetStore } from '../../store/projetStore';
import { formatDate } from '../../utils/formatters';
import { Link } from 'react-router-dom';

interface LiaisonProjetsProps {
  projetId: string;
}

export function LiaisonProjets({ projetId }: LiaisonProjetsProps) {
  const [showModal, setShowModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const { projets, updateProjetsLies } = useProjetStore();
  const projetActuel = projets.find(p => p.id === projetId);
  const [projetsLies, setProjetsLies] = useState<string[]>(projetActuel?.projetsLies || []);

  const projetsFiltrés = projets
    .filter(p => p.id !== projetId)
    .filter(p => 
      p.titre.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.reference.toLowerCase().includes(searchTerm.toLowerCase())
    );

  const handleToggleLiaison = (id: string) => {
    setProjetsLies(prev => 
      prev.includes(id) 
        ? prev.filter(p => p !== id)
        : [...prev, id]
    );
  };

  const handleSave = () => {
    updateProjetsLies(projetId, projetsLies);
    setShowModal(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium flex items-center">
          <LinkIcon className="h-5 w-5 mr-2" />
          Projets liés
        </h3>
        <button
          onClick={() => setShowModal(true)}
          className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
        >
          <LinkIcon className="h-4 w-4 mr-2" />
          Lier des projets
        </button>
      </div>

      {projetsLies.length > 0 ? (
        <div className="space-y-2">
          {projetsLies.map(id => {
            const projet = projets.find(p => p.id === id);
            if (!projet) return null;
            return (
              <div key={id} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                <div>
                  <Link to={`/projets/${projet.id}`} className="font-medium text-gray-900 hover:text-[#1B4332]">
                    {projet.titre}
                  </Link>
                  <p className="text-sm text-gray-500">
                    {projet.reference} • {projet.etat.replace('_', ' ')}
                  </p>
                </div>
                <button
                  onClick={() => handleToggleLiaison(id)}
                  className="text-gray-400 hover:text-gray-500"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            );
          })}
        </div>
      ) : (
        <p className="text-gray-500 text-center py-4">
          Aucun projet lié
        </p>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-medium">Lier des projets</h2>
              <button
                onClick={() => setShowModal(false)}
                className="text-gray-400 hover:text-gray-500"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            <div className="relative mb-4">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Rechercher un projet..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-[#1B4332] focus:border-[#1B4332]"
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>

            <div className="max-h-96 overflow-y-auto">
              <ul className="divide-y divide-gray-200">
                {projetsFiltrés.map(projet => (
                  <li
                    key={projet.id}
                    className="py-4 flex items-center hover:bg-gray-50 cursor-pointer"
                    onClick={() => handleToggleLiaison(projet.id)}
                  >
                    <input
                      type="checkbox"
                      checked={projetsLies.includes(projet.id)}
                      onChange={() => handleToggleLiaison(projet.id)}
                      className="h-4 w-4 text-[#1B4332] border-gray-300 rounded focus:ring-[#1B4332]"
                    />
                    <div className="ml-3">
                      <p className="font-medium text-gray-900">{projet.titre}</p>
                      <p className="text-sm text-gray-500">
                        {projet.reference} • {projet.etat.replace('_', ' ')}
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>

            <div className="mt-6 flex justify-end space-x-3">
              <button
                onClick={() => setShowModal(false)}
                className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
              >
                Annuler
              </button>
              <button
                onClick={handleSave}
                className="px-4 py-2 bg-[#1B4332] text-white rounded-md hover:bg-[#9B2242]"
              >
                Enregistrer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}