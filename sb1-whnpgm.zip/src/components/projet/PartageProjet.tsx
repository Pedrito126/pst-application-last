import React, { useState } from 'react';
import { Mail } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Projet } from '../../types/projet';
import { generateProjetPDF } from '../../utils/pdfGenerator';

const partageSchema = z.object({
  email: z.string().email('Email invalide'),
  message: z.string().optional(),
});

type PartageForm = z.infer<typeof partageSchema>;

interface PartageProjetProps {
  projet: Projet;
}

export function PartageProjet({ projet }: PartageProjetProps) {
  const [showModal, setShowModal] = useState(false);
  const [success, setSuccess] = useState(false);

  const { register, handleSubmit, reset, formState: { errors } } = useForm<PartageForm>({
    resolver: zodResolver(partageSchema),
  });

  const onSubmit = async (data: PartageForm) => {
    try {
      // Simulation d'envoi d'email
      console.log('Envoi du projet par email:', {
        to: data.email,
        message: data.message,
        projet: projet.titre,
      });
      
      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        setShowModal(false);
        reset();
      }, 2000);
    } catch (error) {
      console.error('Erreur lors de l\'envoi:', error);
    }
  };

  return (
    <>
      <button
        onClick={() => setShowModal(true)}
        className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
      >
        <Mail className="h-5 w-5 mr-2" />
        Partager
      </button>

      {showModal && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <h3 className="text-lg font-medium mb-4">
              Partager la fiche projet
            </h3>

            {success ? (
              <div className="text-green-600 text-center py-4">
                Email envoyé avec succès !
              </div>
            ) : (
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Email du destinataire
                  </label>
                  <input
                    type="email"
                    {...register('email')}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                  {errors.email && (
                    <p className="mt-1 text-sm text-red-600">{errors.email.message}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Message (optionnel)
                  </label>
                  <textarea
                    {...register('message')}
                    rows={3}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={() => setShowModal(false)}
                    className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
                  >
                    Envoyer
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </>
  );
}