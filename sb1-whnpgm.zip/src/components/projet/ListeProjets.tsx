import React from 'react';
import { useProjetStore } from '../../store/projetStore';
import { useAuthStore } from '../../store/authStore';
import { formatDate, formatMontant } from '../../utils/formatters';
import { FileEdit, Trash2, Eye, Copy } from 'lucide-react';
import { Link } from 'react-router-dom';
import { DuplicationModal } from './DuplicationModal';

export function ListeProjets() {
  const { projets, supprimerProjet } = useProjetStore();
  const user = useAuthStore((state) => state.user);
  const [showDuplicationModal, setShowDuplicationModal] = React.useState(false);
  const [projetADupliquer, setProjetADupliquer] = React.useState<string | null>(null);

  const canEdit = ['ADMIN', 'DG', 'DF'].includes(user?.role || '');
  const canDelete = ['ADMIN', 'DG'].includes(user?.role || '');
  const showFinancials = ['ADMIN', 'DG', 'DF'].includes(user?.role || '');

  const handleDelete = (projetId: string, titre: string) => {
    if (window.confirm(`Êtes-vous sûr de vouloir supprimer le projet "${titre}" ?`)) {
      supprimerProjet(projetId);
    }
  };

  const handleDuplication = (projetId: string) => {
    setProjetADupliquer(projetId);
    setShowDuplicationModal(true);
  };

  const getEtatCouleur = (etat: string) => {
    const couleurs = {
      BROUILLON: 'bg-gray-100 text-gray-800',
      NON_DEMARRE: 'bg-blue-100 text-blue-800',
      EN_COURS: 'bg-yellow-100 text-yellow-800',
      TERMINE: 'bg-green-100 text-green-800',
      BLOQUE: 'bg-red-100 text-red-800',
    };
    return couleurs[etat] || couleurs.BROUILLON;
  };

  return (
    <>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Référence
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Titre
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                État
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Priorité
              </th>
              {showFinancials && (
                <>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Budget
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Subside
                  </th>
                </>
              )}
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Mise à jour
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {projets.map((projet) => (
              <tr key={projet.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {projet.reference}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {projet.titre}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getEtatCouleur(projet.etat)}`}>
                    {projet.etat.replace('_', ' ')}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {projet.priorite}
                </td>
                {showFinancials && (
                  <>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {formatMontant(projet.budgetActualise)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {projet.subside.actif ? formatMontant(projet.subside.montant) : '-'}
                    </td>
                  </>
                )}
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {formatDate(projet.dateMiseAJour)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <div className="flex justify-end space-x-2">
                    <Link
                      to={`/projets/${projet.id}`}
                      className="text-blue-600 hover:text-blue-900 group relative"
                      title="Voir les détails"
                    >
                      <Eye className="h-5 w-5" />
                      <span className="invisible group-hover:visible absolute -top-8 -left-12 bg-gray-900 text-white text-xs rounded py-1 px-2 whitespace-nowrap">
                        Voir les détails
                      </span>
                    </Link>
                    {canEdit && (
                      <Link
                        to={`/projets/${projet.id}/modifier`}
                        className="text-indigo-600 hover:text-indigo-900 group relative"
                        title="Modifier le projet"
                      >
                        <FileEdit className="h-5 w-5" />
                        <span className="invisible group-hover:visible absolute -top-8 -left-14 bg-gray-900 text-white text-xs rounded py-1 px-2 whitespace-nowrap">
                          Modifier le projet
                        </span>
                      </Link>
                    )}
                    <button
                      onClick={() => handleDuplication(projet.id)}
                      className="text-green-600 hover:text-green-900 group relative"
                      title="Dupliquer le projet"
                    >
                      <Copy className="h-5 w-5" />
                      <span className="invisible group-hover:visible absolute -top-8 -left-14 bg-gray-900 text-white text-xs rounded py-1 px-2 whitespace-nowrap">
                        Dupliquer le projet
                      </span>
                    </button>
                    {canDelete && (
                      <button
                        onClick={() => handleDelete(projet.id, projet.titre)}
                        className="text-red-600 hover:text-red-900 group relative"
                        title="Supprimer le projet"
                      >
                        <Trash2 className="h-5 w-5" />
                        <span className="invisible group-hover:visible absolute -top-8 -left-14 bg-gray-900 text-white text-xs rounded py-1 px-2 whitespace-nowrap">
                          Supprimer le projet
                        </span>
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showDuplicationModal && projetADupliquer && (
        <DuplicationModal
          projetId={projetADupliquer}
          onClose={() => {
            setShowDuplicationModal(false);
            setProjetADupliquer(null);
          }}
        />
      )}
    </>
  );
}