import React from 'react';
import { ODD } from '../../config/auth';

interface BadgeODDProps {
  oddId: number;
  className?: string;
}

export function BadgeODD({ oddId, className = '' }: BadgeODDProps) {
  const odd = ODD.find(o => o.id === oddId);
  
  if (!odd) return null;

  return (
    <span
      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${className}`}
      style={{
        backgroundColor: `${odd.couleur}20`,
        color: odd.couleur,
      }}
    >
      ODD {odd.id} - {odd.titre}
    </span>
  );
}