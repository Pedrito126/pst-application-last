import React from 'react';
import { ODD } from '../../config/auth';

interface SelecteurODDProps {
  value: number;
  onChange: (value: number) => void;
  error?: string;
}

export function SelecteurODD({ value, onChange, error }: SelecteurODDProps) {
  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-gray-700">
        Objectif de Développement Durable
      </label>
      
      <select
        value={value || ''}
        onChange={(e) => onChange(Number(e.target.value))}
        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
      >
        <option value="">Sélectionnez un ODD</option>
        {ODD.map((odd) => (
          <option 
            key={odd.id} 
            value={odd.id}
            style={{ backgroundColor: odd.couleur + '20' }}
          >
            ODD {odd.id.toString().padStart(2, '0')} - {odd.titre}
          </option>
        ))}
      </select>

      {value > 0 && (
        <div 
          className="p-3 rounded-md relative group cursor-help"
          style={{ 
            backgroundColor: `${ODD.find(o => o.id === value)?.couleur}20`,
            borderLeft: `4px solid ${ODD.find(o => o.id === value)?.couleur}`
          }}
        >
          <p className="font-medium" style={{ color: ODD.find(o => o.id === value)?.couleur }}>
            {ODD.find(o => o.id === value)?.titre}
          </p>
          <div className="hidden group-hover:block absolute z-10 w-96 p-4 mt-2 bg-white rounded-lg shadow-lg border border-gray-200">
            <p className="text-sm text-gray-600">
              {ODD.find(o => o.id === value)?.description}
            </p>
          </div>
        </div>
      )}
      
      {error && (
        <p className="mt-1 text-sm text-red-600">{error}</p>
      )}
    </div>
  );
}