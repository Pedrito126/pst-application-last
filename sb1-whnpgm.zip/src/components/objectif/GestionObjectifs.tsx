import React, { useState, useRef } from 'react';
import { Plus, Printer, Download, Edit, Trash2 } from 'lucide-react';
import { useObjectifStore } from '../../store/objectifStore';
import { useProjetStore } from '../../store/projetStore';
import { FormulaireObjectif } from './FormulaireObjectif';
import { useReactToPrint } from 'react-to-print';
import { generateProjetPDF } from '../../utils/pdfGenerator';
import { useNotifications } from '../notifications/NotificationsProvider';
import { ObjectifStrategique, ObjectifOperationnel } from '../../types/objectif';

type PrintMode = 'current' | 'all';
type PrintDepth = 'OS' | 'OO' | 'FULL';

export function GestionObjectifs() {
  const [activeVolet, setActiveVolet] = useState<'INTERNE' | 'EXTERNE'>('INTERNE');
  const [showFormOS, setShowFormOS] = useState(false);
  const [showFormOO, setShowFormOO] = useState(false);
  const [selectedOSId, setSelectedOSId] = useState<string | null>(null);
  const [editingOS, setEditingOS] = useState<ObjectifStrategique | null>(null);
  const [editingOO, setEditingOO] = useState<ObjectifOperationnel | null>(null);
  const [printMode, setPrintMode] = useState<PrintMode>('current');
  const [printDepth, setPrintDepth] = useState<PrintDepth>('FULL');
  
  const { objectifsStrategiques, objectifsOperationnels, supprimerObjectifStrategique, supprimerObjectifOperationnel } = useObjectifStore();
  const { projets } = useProjetStore();
  const { addNotification } = useNotifications();
  const printRef = useRef(null);

  const handlePrint = useReactToPrint({
    content: () => printRef.current,
  });

  const handleAddOS = () => {
    setEditingOS(null);
    setShowFormOS(true);
  };

  const handleEditOS = (os: ObjectifStrategique) => {
    setEditingOS(os);
    setShowFormOS(true);
  };

  const handleAddOO = (osId: string) => {
    setSelectedOSId(osId);
    setEditingOO(null);
    setShowFormOO(true);
  };

  const handleEditOO = (oo: ObjectifOperationnel) => {
    setSelectedOSId(oo.objectifStrategiqueId);
    setEditingOO(oo);
    setShowFormOO(true);
  };

  const handleDeleteOS = (os: ObjectifStrategique) => {
    const projetsLies = projets.filter(p => p.objectifStrategique === os.id);
    if (projetsLies.length > 0) {
      addNotification('error', 'Impossible de supprimer cet objectif stratégique car il est lié à des projets');
      return;
    }

    if (window.confirm(`Êtes-vous sûr de vouloir supprimer l'objectif stratégique "${os.titre}" ?`)) {
      supprimerObjectifStrategique(os.id);
      addNotification('success', 'Objectif stratégique supprimé avec succès');
    }
  };

  const handleDeleteOO = (oo: ObjectifOperationnel) => {
    const projetsLies = projets.filter(p => p.objectifOperationnel === oo.id);
    if (projetsLies.length > 0) {
      addNotification('error', 'Impossible de supprimer cet objectif opérationnel car il est lié à des projets');
      return;
    }

    if (window.confirm(`Êtes-vous sûr de vouloir supprimer l'objectif opérationnel "${oo.titre}" ?`)) {
      supprimerObjectifOperationnel(oo.id);
      addNotification('success', 'Objectif opérationnel supprimé avec succès');
    }
  };

  const filteredOS = objectifsStrategiques.filter(os => os.volet === activeVolet);

  return (
    <div className="space-y-6">
      {/* ... (reste du code existant jusqu'à la boucle des objectifs) ... */}

      <div ref={printRef} className="space-y-8">
        {filteredOS.map((os) => (
          <div key={os.id} className="border-l-4 border-[#1B4332] pl-4">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-lg font-semibold">{os.titre}</h3>
                <p className="text-gray-600">{os.description}</p>
                <p className="text-sm text-gray-500 mt-1">Code: {os.code}</p>
              </div>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => handleEditOS(os)}
                  className="text-gray-600 hover:text-[#1B4332]"
                  title="Modifier l'objectif stratégique"
                >
                  <Edit className="h-4 w-4" />
                </button>
                <button
                  onClick={() => handleDeleteOS(os)}
                  className="text-gray-600 hover:text-red-600"
                  title="Supprimer l'objectif stratégique"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
                <button
                  onClick={() => handleAddOO(os.id)}
                  className="text-[#1B4332] hover:text-[#9B2242] text-sm font-medium"
                >
                  <Plus className="h-4 w-4 inline-block mr-1" />
                  Ajouter un objectif opérationnel
                </button>
              </div>
            </div>

            <div className="mt-4 space-y-4">
              {objectifsOperationnels
                .filter((oo) => oo.objectifStrategiqueId === os.id)
                .map((oo) => (
                  <div key={oo.id} className="ml-6 border-l-2 border-gray-200 pl-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-medium">{oo.titre}</h4>
                        <p className="text-gray-600 text-sm">{oo.description}</p>
                        <p className="text-sm text-gray-500 mt-1">Code: {oo.code}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => handleEditOO(oo)}
                          className="text-gray-600 hover:text-[#1B4332]"
                          title="Modifier l'objectif opérationnel"
                        >
                          <Edit className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteOO(oo)}
                          className="text-gray-600 hover:text-red-600"
                          title="Supprimer l'objectif opérationnel"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                    
                    {printDepth === 'FULL' && (
                      <div className="mt-2 space-y-2">
                        {projets
                          .filter(
                            (p) =>
                              p.objectifStrategique === os.id &&
                              p.objectifOperationnel === oo.id
                          )
                          .map((projet) => (
                            <div
                              key={projet.id}
                              className="text-sm text-gray-500 ml-4"
                            >
                              • {projet.titre}
                            </div>
                          ))}
                      </div>
                    )}
                  </div>
                ))}
            </div>
          </div>
        ))}
      </div>

      {showFormOS && (
        <FormulaireObjectif
          type="strategique"
          volet={activeVolet}
          objectif={editingOS}
          onClose={() => {
            setShowFormOS(false);
            setEditingOS(null);
          }}
        />
      )}

      {showFormOO && selectedOSId && (
        <FormulaireObjectif
          type="operationnel"
          objectifStrategiqueId={selectedOSId}
          objectif={editingOO}
          onClose={() => {
            setShowFormOO(false);
            setSelectedOSId(null);
            setEditingOO(null);
          }}
        />
      )}
    </div>
  );
}