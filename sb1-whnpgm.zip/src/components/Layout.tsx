import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import { Type as TextSize, LogOut } from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import { Navigation } from './Navigation';

export function Layout() {
  const [fontSize, setFontSize] = useState('text-base');
  const { user, logout } = useAuthStore();

  const toggleFontSize = () => {
    setFontSize(current => 
      current === 'text-base' ? 'text-lg' : 
      current === 'text-lg' ? 'text-xl' : 'text-base'
    );
  };

  return (
    <div className={`min-h-screen flex flex-col bg-gray-50 ${fontSize}`}>
      <header className="bg-[#1B4332] text-white">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-center flex-grow">
              Gestion PST - Commune d'Ittre
            </h1>
            <div className="flex items-center space-x-4">
              {user && (
                <span className="text-sm whitespace-nowrap">
                  Connecté: {user.name}
                </span>
              )}
              <button
                onClick={toggleFontSize}
                className="p-2 hover:bg-[#9B2242] rounded-full transition-colors"
                title="Ajuster la taille du texte"
              >
                <TextSize className="h-5 w-5" />
              </button>
              <button
                onClick={logout}
                className="p-2 hover:bg-[#9B2242] rounded-full transition-colors"
                title="Déconnexion"
              >
                <LogOut className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
        <Navigation />
      </header>

      <main className="flex-grow">
        <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
          <Outlet />
        </div>
      </main>

      <footer className="bg-[#1B4332] text-white py-2">
        <div className="max-w-7xl mx-auto px-4 text-center text-xs">
          Proudly propulsed by Pedro Sevilla - GestionPST 2024
        </div>
      </footer>
    </div>
  );
}