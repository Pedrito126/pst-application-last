import React from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, Target, FileText, Users, List, HelpCircle, Settings } from 'lucide-react';
import { useAuthStore } from '../store/authStore';

export function Navigation() {
  const user = useAuthStore((state) => state.user);

  const navItems = [
    {
      to: '/dashboard',
      icon: <LayoutDashboard className="h-5 w-5" />,
      label: 'Tableau de bord',
    },
    {
      to: '/objectifs',
      icon: <Target className="h-5 w-5" />,
      label: 'Objectifs',
    },
    {
      to: '/projets/nouveau',
      icon: <FileText className="h-5 w-5" />,
      label: 'Nouveau projet',
    },
    {
      to: '/preferences',
      icon: <Settings className="h-5 w-5" />,
      label: 'Préférences',
    },
    {
      to: '/aide',
      icon: <HelpCircle className="h-5 w-5" />,
      label: 'Assistance',
    }
  ];

  if (user?.role === 'ADMIN') {
    navItems.push(
      {
        to: '/admin/utilisateurs',
        icon: <Users className="h-5 w-5" />,
        label: 'Utilisateurs',
      },
      {
        to: '/admin/projets',
        icon: <List className="h-5 w-5" />,
        label: 'Liste des projets',
      }
    );
  }

  return (
    <nav className="bg-[#1B4332] border-t border-[#9B2242]/20">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex space-x-4">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `flex items-center px-4 py-3 text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-[#9B2242] text-white'
                    : 'text-gray-100 hover:bg-[#9B2242] hover:text-white'
                }`
              }
              title={item.label}
            >
              {item.icon}
              <span className="ml-2">{item.label}</span>
            </NavLink>
          ))}
        </div>
      </div>
    </nav>
  );
}