import React from 'react';
import { Download, FileText, HelpCircle } from 'lucide-react';
import { useProjetStore } from '../../store/projetStore';
import { useObjectifStore } from '../../store/objectifStore';
import { useAuthStore } from '../../store/authStore';
import { saveAs } from 'file-saver';
import { Document, Packer, Paragraph, HeadingLevel } from 'docx';
import { contenuManuel } from '../../pages/aide/contenuManuel';
import { backupInstructions } from '../../utils/backupInstructions';

export function ExportBackup() {
  const { projets } = useProjetStore();
  const { objectifsStrategiques, objectifsOperationnels } = useObjectifStore();
  const { users } = useAuthStore();

  const handleExportData = () => {
    const data = {
      projets,
      objectifsStrategiques,
      objectifsOperationnels,
      users,
      exportDate: new Date().toISOString(),
      version: '1.0.0'
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    saveAs(blob, `pst-backup-${new Date().toISOString().split('T')[0]}.json`);
  };

  const handleExportDocs = async () => {
    const doc = new Document({
      sections: [{
        properties: {},
        children: contenuManuel.map(section => [
          new Paragraph({
            text: section.title,
            heading: HeadingLevel.HEADING_1,
          }),
          new Paragraph({
            text: section.content,
          }),
          ...(section.subsections?.map(subsection => [
            new Paragraph({
              text: subsection.title,
              heading: HeadingLevel.HEADING_2,
            }),
            new Paragraph({
              text: subsection.content,
            }),
          ]).flat() || [])
        ]).flat()
      }]
    });

    const blob = await Packer.toBlob(doc);
    saveAs(blob, 'manuel-utilisateur-pst.docx');
  };

  const handleExportInstructions = () => {
    const blob = new Blob([backupInstructions], { type: 'text/plain' });
    saveAs(blob, 'instructions-sauvegarde.txt');
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <h2 className="text-lg font-medium mb-4">Export et sauvegarde</h2>
      <div className="space-y-4">
        <div>
          <h3 className="text-sm font-medium text-gray-700 mb-2">Sauvegarde des données</h3>
          <div className="flex space-x-2">
            <button
              onClick={handleExportData}
              className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-[#1B4332] hover:bg-[#9B2242]"
            >
              <Download className="h-5 w-5 mr-2" />
              Exporter les données
            </button>
            <button
              onClick={handleExportInstructions}
              className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
            >
              <HelpCircle className="h-5 w-5 mr-2" />
              Instructions de sauvegarde
            </button>
          </div>
          <p className="mt-2 text-sm text-gray-500">
            Crée une sauvegarde complète de toutes les données de l'application.
          </p>
        </div>

        <div>
          <h3 className="text-sm font-medium text-gray-700 mb-2">Documentation</h3>
          <button
            onClick={handleExportDocs}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-[#1B4332] hover:bg-[#9B2242]"
          >
            <FileText className="h-5 w-5 mr-2" />
            Exporter la documentation
          </button>
          <p className="mt-2 text-sm text-gray-500">
            Télécharge le manuel utilisateur au format Word pour modification.
          </p>
        </div>
      </div>
    </div>
  );
}