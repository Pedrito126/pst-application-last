import React from 'react';
import { Database, Trash2, Plus } from 'lucide-react';
import { useTestDataStore } from '../../store/testDataStore';
import { useNotifications } from '../notifications/NotificationsProvider';

export function TestDataManager() {
  const { clearTestData, generateTestData } = useTestDataStore();
  const { addNotification } = useNotifications();

  const handleClearData = () => {
    if (window.confirm('Êtes-vous sûr de vouloir supprimer toutes les données de test ?')) {
      clearTestData();
      addNotification('success', 'Données de test supprimées avec succès');
    }
  };

  const handleGenerateData = () => {
    generateTestData();
    addNotification('success', 'Données de test générées avec succès');
  };

  return (
    <div className="bg-white p-4 rounded-lg shadow">
      <h2 className="text-lg font-medium mb-4">Gestion des données de test</h2>
      <div className="flex space-x-4">
        <button
          onClick={handleGenerateData}
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-[#1B4332] hover:bg-[#9B2242]"
        >
          <Plus className="h-5 w-5 mr-2" />
          Générer des données de test
        </button>
        <button
          onClick={handleClearData}
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700"
        >
          <Trash2 className="h-5 w-5 mr-2" />
          Supprimer les données de test
        </button>
      </div>
      <p className="mt-4 text-sm text-gray-500">
        Les données de test sont identifiables par le préfixe "[TEST]".
      </p>
    </div>
  );
}