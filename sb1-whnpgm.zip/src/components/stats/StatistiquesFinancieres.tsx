import React from 'react';
import { Bar, Line } from 'react-chartjs-2';
import { useProjetStore } from '../../store/projetStore';
import { formatMontant } from '../../utils/formatters';

export function StatistiquesFinancieres() {
  const projets = useProjetStore((state) => state.projets);

  // Calcul des statistiques financières
  const statsParAnnee = projets.reduce((acc, projet) => {
    const annee = new Date(projet.dateCreation).getFullYear();
    if (!acc[annee]) {
      acc[annee] = {
        budget: 0,
        subside: 0,
        count: 0,
      };
    }
    acc[annee].budget += projet.budgetActualise;
    acc[annee].subside += projet.subside.actif ? projet.subside.montant : 0;
    acc[annee].count += 1;
    return acc;
  }, {});

  const annees = Object.keys(statsParAnnee).sort();
  const budgets = annees.map(annee => statsParAnnee[annee].budget);
  const subsides = annees.map(annee => statsParAnnee[annee].subside);

  // Calcul du taux de couverture des subsides
  const tauxCouverture = projets.reduce((acc, projet) => {
    if (projet.budgetActualise > 0) {
      acc.push((projet.subside.actif ? projet.subside.montant : 0) / projet.budgetActualise * 100);
    }
    return acc;
  }, []);

  const moyenneCouverture = tauxCouverture.length > 0 
    ? tauxCouverture.reduce((a, b) => a + b, 0) / tauxCouverture.length 
    : 0;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-lg shadow">
          <h3 className="text-lg font-medium mb-2">Budget total</h3>
          <p className="text-3xl font-bold text-blue-600">
            {formatMontant(budgets.reduce((a, b) => a + b, 0))}
          </p>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <h3 className="text-lg font-medium mb-2">Total des subsides</h3>
          <p className="text-3xl font-bold text-green-600">
            {formatMontant(subsides.reduce((a, b) => a + b, 0))}
          </p>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <h3 className="text-lg font-medium mb-2">Taux moyen de couverture</h3>
          <p className="text-3xl font-bold text-purple-600">
            {moyenneCouverture.toFixed(1)}%
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-4 rounded-lg shadow">
          <h3 className="text-lg font-medium mb-4">Évolution budgétaire</h3>
          <div className="h-64">
            <Line
              data={{
                labels: annees,
                datasets: [
                  {
                    label: 'Budget',
                    data: budgets,
                    borderColor: 'rgb(59, 130, 246)',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    fill: true,
                  },
                  {
                    label: 'Subsides',
                    data: subsides,
                    borderColor: 'rgb(34, 197, 94)',
                    backgroundColor: 'rgba(34, 197, 94, 0.1)',
                    fill: true,
                  },
                ],
              }}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                  y: {
                    beginAtZero: true,
                    ticks: {
                      callback: (value) => formatMontant(value as number),
                    },
                  },
                },
              }}
            />
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg shadow">
          <h3 className="text-lg font-medium mb-4">Répartition par priorité</h3>
          <div className="h-64">
            <Bar
              data={{
                labels: ['P1 (2024-2026)', 'P2 (2026-2028)', 'P3 (2028-2030)'],
                datasets: [
                  {
                    label: 'Budget',
                    data: [
                      projets.filter(p => p.priorite === 'P1').reduce((sum, p) => sum + p.budgetActualise, 0),
                      projets.filter(p => p.priorite === 'P2').reduce((sum, p) => sum + p.budgetActualise, 0),
                      projets.filter(p => p.priorite === 'P3').reduce((sum, p) => sum + p.budgetActualise, 0),
                    ],
                    backgroundColor: [
                      'rgba(239, 68, 68, 0.5)',
                      'rgba(245, 158, 11, 0.5)',
                      'rgba(34, 197, 94, 0.5)',
                    ],
                  },
                ],
              }}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                  y: {
                    beginAtZero: true,
                    ticks: {
                      callback: (value) => formatMontant(value as number),
                    },
                  },
                },
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}