import React, { useEffect, useRef } from 'react';
import { Bar, Doughnut } from 'react-chartjs-2';
import { Settings } from 'lucide-react';
import { useProjetStore } from '../../store/projetStore';
import { useObjectifStore } from '../../store/objectifStore';
import { ODD } from '../../config/auth';
import { EtatProjet } from '../../types/projet';

export function StatistiquesDashboard() {
  const projets = useProjetStore((state) => state.projets);
  const { objectifsStrategiques, objectifsOperationnels } = useObjectifStore();
  const [showConfig, setShowConfig] = React.useState(false);
  const chartRefs = useRef<{ [key: string]: any }>({});

  useEffect(() => {
    return () => {
      Object.values(chartRefs.current).forEach(ref => {
        if (ref?.current?.chartInstance) {
          ref.current.chartInstance.destroy();
        }
      });
    };
  }, []);

  const getDataForEtats = () => {
    const etats: Record<EtatProjet, number> = {
      'BROUILLON': 0,
      'NON_DEMARRE': 0,
      'EN_COURS': 0,
      'TERMINE': 0,
      'BLOQUE': 0
    };

    projets.forEach(projet => {
      etats[projet.etat]++;
    });

    return {
      labels: ['Brouillon', 'Non démarré', 'En cours', 'Terminé', 'Bloqué'],
      datasets: [{
        data: Object.values(etats),
        backgroundColor: [
          '#94a3b8', // Brouillon - Gris
          '#60a5fa', // Non démarré - Bleu
          '#fbbf24', // En cours - Jaune
          '#22c55e', // Terminé - Vert
          '#ef4444'  // Bloqué - Rouge
        ]
      }]
    };
  };

  const getDataForODD = () => {
    // Ne compter que les projets qui ne sont pas en brouillon
    const oddCount = {};
    projets
      .filter(projet => projet.etat !== 'BROUILLON')
      .forEach(projet => {
        oddCount[projet.refODD] = (oddCount[projet.refODD] || 0) + 1;
      });

    return {
      labels: Object.keys(oddCount).map(id => `ODD ${id}`),
      datasets: [{
        data: Object.values(oddCount),
        backgroundColor: Object.keys(oddCount).map(id => 
          ODD.find(o => o.id === parseInt(id))?.couleur || '#000000'
        )
      }]
    };
  };

  const getDataForObjectifs = () => {
    // Compter les projets actifs (non brouillons) par volet
    const projetParVolet = projets
      .filter(projet => projet.etat !== 'BROUILLON')
      .reduce((acc, projet) => {
        acc[projet.volet] = (acc[projet.volet] || 0) + 1;
        return acc;
      }, {});

    const osData = objectifsStrategiques.reduce((acc, os) => {
      acc[os.volet] = (acc[os.volet] || 0) + 1;
      return acc;
    }, {});

    const ooData = objectifsOperationnels.reduce((acc, oo) => {
      const os = objectifsStrategiques.find(o => o.id === oo.objectifStrategiqueId);
      if (os) {
        acc[os.volet] = (acc[os.volet] || 0) + 1;
      }
      return acc;
    }, {});

    return {
      labels: ['Volet Interne', 'Volet Externe'],
      datasets: [
        {
          label: 'Objectifs Stratégiques',
          data: [osData['INTERNE'] || 0, osData['EXTERNE'] || 0],
          backgroundColor: '#1B4332',
        },
        {
          label: 'Objectifs Opérationnels',
          data: [ooData['INTERNE'] || 0, ooData['EXTERNE'] || 0],
          backgroundColor: '#9B2242',
        },
        {
          label: 'Projets Actifs',
          data: [projetParVolet['INTERNE'] || 0, projetParVolet['EXTERNE'] || 0],
          backgroundColor: '#60a5fa',
        }
      ]
    };
  };

  const getProgressionStats = () => {
    const total = projets.length;
    const brouillons = projets.filter(p => p.etat === 'BROUILLON').length;
    const actifs = total - brouillons;
    const termines = projets.filter(p => p.etat === 'TERMINE').length;

    const progressionPourcentage = actifs > 0 ? (termines / actifs) * 100 : 0;

    return {
      labels: ['Progression globale'],
      datasets: [{
        data: [progressionPourcentage, 100 - progressionPourcentage],
        backgroundColor: ['#22c55e', '#e5e7eb']
      }]
    };
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-4 rounded-lg shadow">
          <h3 className="text-lg font-medium mb-4">État des projets</h3>
          <div className="h-64">
            <Doughnut
              ref={el => chartRefs.current.etats = el}
              data={getDataForEtats()}
              options={{
                plugins: {
                  legend: {
                    position: 'bottom'
                  },
                  tooltip: {
                    callbacks: {
                      label: function(context) {
                        const total = context.dataset.data.reduce((a: number, b: number) => a + b, 0);
                        const value = context.raw as number;
                        const percentage = ((value / total) * 100).toFixed(1);
                        return `${value} projets (${percentage}%)`;
                      }
                    }
                  }
                }
              }}
            />
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg shadow">
          <h3 className="text-lg font-medium mb-4">Progression globale</h3>
          <div className="h-64">
            <Doughnut
              ref={el => chartRefs.current.progression = el}
              data={getProgressionStats()}
              options={{
                plugins: {
                  legend: {
                    display: false
                  },
                  tooltip: {
                    callbacks: {
                      label: function(context) {
                        return `${context.raw.toFixed(1)}%`;
                      }
                    }
                  }
                },
                cutout: '75%'
              }}
            />
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg shadow">
          <h3 className="text-lg font-medium mb-4">Répartition par ODD</h3>
          <div className="h-64">
            <Bar
              ref={el => chartRefs.current.odd = el}
              data={getDataForODD()}
              options={{
                plugins: {
                  legend: {
                    display: false
                  },
                  tooltip: {
                    callbacks: {
                      title: function(context) {
                        const oddId = parseInt(context[0].label.split(' ')[1]);
                        const odd = ODD.find(o => o.id === oddId);
                        return odd ? `${odd.titre}` : context[0].label;
                      }
                    }
                  }
                },
                scales: {
                  y: {
                    beginAtZero: true,
                    ticks: {
                      stepSize: 1
                    }
                  }
                }
              }}
            />
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg shadow">
          <h3 className="text-lg font-medium mb-4">Répartition des objectifs</h3>
          <div className="h-64">
            <Bar
              ref={el => chartRefs.current.objectifs = el}
              data={getDataForObjectifs()}
              options={{
                plugins: {
                  legend: {
                    position: 'bottom'
                  }
                },
                scales: {
                  y: {
                    beginAtZero: true,
                    ticks: {
                      stepSize: 1
                    }
                  }
                }
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}