import React from 'react';
import { AlertTriangle } from 'lucide-react';
import { useProjetStore } from '../../store/projetStore';
import { formatMontant } from '../../utils/formatters';

export function AlertesBudgetaires() {
  const projets = useProjetStore((state) => state.projets);

  const alertes = projets
    .filter(projet => {
      const tauxCouverture = projet.subside.actif 
        ? (projet.subside.montant / projet.budgetActualise) * 100 
        : 0;
      return (
        (projet.budgetActualise > 100000 && tauxCouverture < 20) || // Gros projets peu subsidiés
        (projet.etat === 'EN_COURS' && projet.budgetActualise === 0) || // Projets sans budget
        (projet.subside.actif && projet.subside.montant > projet.budgetActualise) // Anomalie subside > budget
      );
    })
    .map(projet => ({
      id: projet.id,
      titre: projet.titre,
      type: projet.budgetActualise > 100000 ? 'GROS_PROJET' : 
            projet.budgetActualise === 0 ? 'SANS_BUDGET' : 'ANOMALIE_SUBSIDE',
      budget: projet.budgetActualise,
      subside: projet.subside.montant
    }));

  if (alertes.length === 0) return null;

  return (
    <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-6">
      <div className="flex items-center">
        <AlertTriangle className="h-5 w-5 text-yellow-400" />
        <h3 className="ml-2 text-sm font-medium text-yellow-800">
          Alertes budgétaires ({alertes.length})
        </h3>
      </div>
      <div className="mt-2">
        {alertes.map((alerte) => (
          <div key={alerte.id} className="mt-2 text-sm text-yellow-700">
            <p className="font-medium">{alerte.titre}</p>
            <p>
              {alerte.type === 'GROS_PROJET' && 
                `Projet important (${formatMontant(alerte.budget)}) avec faible taux de subvention`}
              {alerte.type === 'SANS_BUDGET' && 
                'Projet en cours sans budget défini'}
              {alerte.type === 'ANOMALIE_SUBSIDE' && 
                `Subside (${formatMontant(alerte.subside)}) supérieur au budget (${formatMontant(alerte.budget)})`}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}