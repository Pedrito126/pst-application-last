import React from 'react';
import { Annexe } from '../../types/annexe';
import { FileText, Image as ImageIcon, FileSpreadsheet, File } from 'lucide-react';

interface PreviewAnnexeProps {
  annexe: Annexe;
  onClose: () => void;
}

export function PreviewAnnexe({ annexe, onClose }: PreviewAnnexeProps) {
  const renderPreview = () => {
    switch (annexe.type) {
      case 'image':
        return (
          <div className="relative w-full h-96">
            <img
              src={annexe.url}
              alt={annexe.nom}
              className="w-full h-full object-contain"
            />
          </div>
        );
      case 'pdf':
        return (
          <iframe
            src={`${annexe.url}#toolbar=0`}
            className="w-full h-96"
            title={annexe.nom}
          />
        );
      case 'office':
        return (
          <iframe
            src={`https://view.officeapps.live.com/op/embed.aspx?src=${encodeURIComponent(annexe.url)}`}
            className="w-full h-96"
            title={annexe.nom}
          />
        );
      default:
        return (
          <div className="flex flex-col items-center justify-center h-96 bg-gray-50">
            <FileText className="h-16 w-16 text-gray-400 mb-4" />
            <p className="text-gray-600">Aperçu non disponible</p>
          </div>
        );
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-4xl w-full p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-medium flex items-center">
            {annexe.type === 'image' && <ImageIcon className="h-5 w-5 mr-2" />}
            {annexe.type === 'pdf' && <FileText className="h-5 w-5 mr-2" />}
            {annexe.type === 'office' && <FileSpreadsheet className="h-5 w-5 mr-2" />}
            {annexe.type === 'document' && <File className="h-5 w-5 mr-2" />}
            {annexe.nom}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-500"
          >
            ×
          </button>
        </div>

        <div className="border rounded-lg overflow-hidden">
          {renderPreview()}
        </div>

        <div className="mt-4 flex justify-between items-center text-sm text-gray-500">
          <div>
            Version {annexe.version} • Ajouté le {new Date(annexe.dateAjout).toLocaleDateString()}
          </div>
          <div className="flex space-x-2">
            {annexe.tags.map(tag => (
              <span
                key={tag}
                className="px-2 py-1 rounded-full bg-gray-100"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}