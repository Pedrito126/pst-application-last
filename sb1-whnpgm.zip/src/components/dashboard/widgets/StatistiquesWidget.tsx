import React from 'react';
import { BarChart } from 'lucide-react';
import { useProjetStore } from '../../../store/projetStore';
import { Doughnut } from 'react-chartjs-2';

export function StatistiquesWidget() {
  const projets = useProjetStore((state) => state.projets);

  const statsParEtat = projets.reduce((acc, projet) => {
    acc[projet.etat] = (acc[projet.etat] || 0) + 1;
    return acc;
  }, {});

  const data = {
    labels: [
      'Brouillon',
      'Non démarré',
      'En cours',
      'Terminé',
      'Bloqué'
    ],
    datasets: [{
      data: [
        statsParEtat['BROUILLON'] || 0,
        statsParEtat['NON_DEMARRE'] || 0,
        statsParEtat['EN_COURS'] || 0,
        statsParEtat['TERMINE'] || 0,
        statsParEtat['BLOQUE'] || 0
      ],
      backgroundColor: [
        '#94A3B8',
        '#60A5FA',
        '#FCD34D',
        '#34D399',
        '#F87171'
      ]
    }]
  };

  return (
    <div>
      <h3 className="text-lg font-medium mb-4 flex items-center">
        <BarChart className="h-5 w-5 mr-2" />
        État des projets
      </h3>

      <div className="h-64">
        <Doughnut
          data={data}
          options={{
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                position: 'bottom'
              }
            }
          }}
        />
      </div>
    </div>
  );
}