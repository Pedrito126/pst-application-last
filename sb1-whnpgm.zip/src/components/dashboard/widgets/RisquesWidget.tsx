import React from 'react';
import { AlertTriangle } from 'lucide-react';
import { useDashboardStore } from '../../../store/dashboardStore';
import { useProjetStore } from '../../../store/projetStore';
import { formatDate } from '../../../utils/formatters';

export function RisquesWidget() {
  const { risques } = useDashboardStore();
  const projets = useProjetStore((state) => state.projets);

  const risquesImportants = risques
    .filter(r => r.probabilite * r.impact >= 16)
    .sort((a, b) => (b.probabilite * b.impact) - (a.probabilite * a.impact))
    .slice(0, 5);

  return (
    <div>
      <h3 className="text-lg font-medium mb-4 flex items-center">
        <AlertTriangle className="h-5 w-5 mr-2" />
        Risques importants
      </h3>

      {risquesImportants.length === 0 ? (
        <p className="text-gray-500 text-center py-4">
          Aucun risque important identifié
        </p>
      ) : (
        <div className="space-y-4">
          {risquesImportants.map((risque) => {
            const projet = projets.find(p => p.id === risque.projetId);
            const score = risque.probabilite * risque.impact;

            return (
              <div
                key={risque.id}
                className="p-4 rounded-lg bg-red-50 border-l-4 border-red-400"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-medium text-gray-900">
                      {projet?.titre}
                    </h4>
                    <p className="text-sm text-gray-600 mt-1">
                      {risque.description}
                    </p>
                    <div className="flex items-center mt-2 text-sm text-gray-500">
                      <span className="mr-2">
                        Score: {score}/25
                      </span>
                      <span>
                        Identifié le {formatDate(risque.dateIdentification)}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      risque.statut === 'mitige' ? 'bg-green-100 text-green-800' :
                      risque.statut === 'en-cours' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-red-100 text-red-800'
                    }`}>
                      {risque.statut.charAt(0).toUpperCase() + risque.statut.slice(1)}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}