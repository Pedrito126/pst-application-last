import React from 'react';
import { Clock, ArrowRight } from 'lucide-react';
import { useProjetStore } from '../../../store/projetStore';
import { Link } from 'react-router-dom';
import { formatDate } from '../../../utils/formatters';

export function ProjetsRecents() {
  const projets = useProjetStore((state) => state.projets);

  const projetsRecents = projets
    .sort((a, b) => new Date(b.dateMiseAJour).getTime() - new Date(a.dateMiseAJour).getTime())
    .slice(0, 5);

  return (
    <div>
      <h3 className="text-lg font-medium mb-4 flex items-center">
        <Clock className="h-5 w-5 mr-2" />
        Projets récents
      </h3>

      <div className="space-y-4">
        {projetsRecents.map((projet) => (
          <Link
            key={projet.id}
            to={`/projets/${projet.id}`}
            className="block p-4 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors"
          >
            <div className="flex justify-between items-start">
              <div>
                <h4 className="font-medium text-gray-900">{projet.titre}</h4>
                <p className="text-sm text-gray-500">
                  {projet.reference} • Mis à jour le {formatDate(projet.dateMiseAJour)}
                </p>
              </div>
              <ArrowRight className="h-5 w-5 text-gray-400" />
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}