import React from 'react';
import { Bell } from 'lucide-react';
import { useDashboardStore } from '../../../store/dashboardStore';
import { Link } from 'react-router-dom';
import { formatDate } from '../../../utils/formatters';

export function NotificationsWidget() {
  const { notifications, markNotificationAsRead } = useDashboardStore();

  const notificationsRecentes = notifications
    .filter(n => !n.lue)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 5);

  return (
    <div>
      <h3 className="text-lg font-medium mb-4 flex items-center">
        <Bell className="h-5 w-5 mr-2" />
        Notifications récentes
      </h3>

      {notificationsRecentes.length === 0 ? (
        <p className="text-gray-500 text-center py-4">
          Aucune nouvelle notification
        </p>
      ) : (
        <div className="space-y-4">
          {notificationsRecentes.map((notification) => (
            <div
              key={notification.id}
              className={`p-4 rounded-lg ${
                notification.importance === 'haute' ? 'bg-red-50' :
                notification.importance === 'moyenne' ? 'bg-yellow-50' :
                'bg-blue-50'
              }`}
            >
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="font-medium text-gray-900">
                    {notification.titre}
                  </h4>
                  <p className="text-sm text-gray-600 mt-1">
                    {notification.message}
                  </p>
                  <div className="flex items-center mt-2 text-sm text-gray-500">
                    <span>{formatDate(notification.date)}</span>
                    {notification.lienProjet && (
                      <Link
                        to={`/projets/${notification.lienProjet}`}
                        className="ml-2 text-blue-600 hover:text-blue-800"
                      >
                        Voir le projet
                      </Link>
                    )}
                  </div>
                </div>
                <button
                  onClick={() => markNotificationAsRead(notification.id)}
                  className="text-gray-400 hover:text-gray-500"
                >
                  Marquer comme lu
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}