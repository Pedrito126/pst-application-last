import React from 'react';
import { AlertTriangle } from 'lucide-react';
import { useProjetStore } from '../../../store/projetStore';
import { Link } from 'react-router-dom';
import { formatMontant } from '../../../utils/formatters';

export function Alertes() {
  const projets = useProjetStore((state) => state.projets);

  const alertes = projets
    .map(projet => {
      const alertes = [];
      
      // Projets bloqués
      if (projet.etat === 'BLOQUE') {
        alertes.push({
          type: 'danger',
          message: 'Projet bloqué',
          projetId: projet.id,
          titre: projet.titre
        });
      }

      // Budget élevé sans subside
      if (projet.budgetActualise > 100000 && (!projet.subside.actif || projet.subside.montant === 0)) {
        alertes.push({
          type: 'warning',
          message: `Budget important (${formatMontant(projet.budgetActualise)}) sans subside`,
          projetId: projet.id,
          titre: projet.titre
        });
      }

      // Projets sans mise à jour récente
      const derniereMiseAJour = new Date(projet.dateMiseAJour);
      const troisMois = 3 * 30 * 24 * 60 * 60 * 1000;
      if (Date.now() - derniereMiseAJour.getTime() > troisMois) {
        alertes.push({
          type: 'info',
          message: 'Pas de mise à jour depuis plus de 3 mois',
          projetId: projet.id,
          titre: projet.titre
        });
      }

      return alertes;
    })
    .flat()
    .sort((a, b) => {
      const priorite = { danger: 3, warning: 2, info: 1 };
      return priorite[b.type] - priorite[a.type];
    });

  return (
    <div>
      <h3 className="text-lg font-medium mb-4 flex items-center">
        <AlertTriangle className="h-5 w-5 mr-2" />
        Alertes ({alertes.length})
      </h3>

      {alertes.length === 0 ? (
        <p className="text-gray-500 text-center py-4">
          Aucune alerte à signaler
        </p>
      ) : (
        <div className="space-y-4">
          {alertes.map((alerte, index) => (
            <div
              key={`${alerte.projetId}-${index}`}
              className={`p-4 rounded-lg ${
                alerte.type === 'danger' ? 'bg-red-50 border-l-4 border-red-400' :
                alerte.type === 'warning' ? 'bg-yellow-50 border-l-4 border-yellow-400' :
                'bg-blue-50 border-l-4 border-blue-400'
              }`}
            >
              <Link
                to={`/projets/${alerte.projetId}`}
                className="font-medium text-gray-900 hover:text-[#1B4332]"
              >
                {alerte.titre}
              </Link>
              <p className="text-sm text-gray-600 mt-1">
                {alerte.message}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}