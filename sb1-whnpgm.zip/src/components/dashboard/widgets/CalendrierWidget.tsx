import React from 'react';
import { Calendar } from 'lucide-react';
import { useDashboardStore } from '../../../store/dashboardStore';
import { formatDate } from '../../../utils/formatters';

export function CalendrierWidget() {
  const { reunions } = useDashboardStore();

  const reunionsAVenir = reunions
    .filter(r => new Date(r.date) > new Date())
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .slice(0, 5);

  return (
    <div>
      <h3 className="text-lg font-medium mb-4 flex items-center">
        <Calendar className="h-5 w-5 mr-2" />
        Prochaines réunions
      </h3>

      {reunionsAVenir.length === 0 ? (
        <p className="text-gray-500 text-center py-4">
          Aucune réunion planifiée
        </p>
      ) : (
        <div className="space-y-4">
          {reunionsAVenir.map((reunion) => (
            <div
              key={reunion.id}
              className="p-4 rounded-lg bg-gray-50"
            >
              <h4 className="font-medium text-gray-900">{reunion.titre}</h4>
              <p className="text-sm text-gray-600 mt-1">{reunion.description}</p>
              <div className="flex items-center mt-2 text-sm text-gray-500">
                <span>{formatDate(reunion.date)}</span>
                <span className="mx-2">•</span>
                <span>{reunion.duree} minutes</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}