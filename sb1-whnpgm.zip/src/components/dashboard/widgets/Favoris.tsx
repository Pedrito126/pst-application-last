import React from 'react';
import { Star, ArrowRight } from 'lucide-react';
import { useProjetStore } from '../../../store/projetStore';
import { useDashboardStore } from '../../../store/dashboardStore';
import { useAuthStore } from '../../../store/authStore';
import { Link } from 'react-router-dom';
import { formatDate } from '../../../utils/formatters';

export function Favoris() {
  const user = useAuthStore((state) => state.user);
  const { getConfig, toggleFavori } = useDashboardStore();
  const projets = useProjetStore((state) => state.projets);

  if (!user) return null;

  const config = getConfig(user.id);
  const projetsFavoris = projets.filter(p => config.favoris.includes(p.id));

  return (
    <div>
      <h3 className="text-lg font-medium mb-4 flex items-center">
        <Star className="h-5 w-5 mr-2" />
        Projets favoris
      </h3>

      {projetsFavoris.length === 0 ? (
        <p className="text-gray-500 text-center py-4">
          Aucun projet favori pour le moment
        </p>
      ) : (
        <div className="space-y-4">
          {projetsFavoris.map((projet) => (
            <div
              key={projet.id}
              className="p-4 rounded-lg bg-gray-50 flex justify-between items-start"
            >
              <div>
                <Link
                  to={`/projets/${projet.id}`}
                  className="font-medium text-gray-900 hover:text-[#1B4332]"
                >
                  {projet.titre}
                </Link>
                <p className="text-sm text-gray-500">
                  {projet.reference} • Mis à jour le {formatDate(projet.dateMiseAJour)}
                </p>
              </div>
              <button
                onClick={() => toggleFavori(user.id, projet.id)}
                className="text-yellow-500 hover:text-yellow-600"
                title="Retirer des favoris"
              >
                <Star className="h-5 w-5 fill-current" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}