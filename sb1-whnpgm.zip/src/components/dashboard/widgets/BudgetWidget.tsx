import React from 'react';
import { DollarSign } from 'lucide-react';
import { useProjetStore } from '../../../store/projetStore';
import { formatMontant } from '../../../utils/formatters';
import { Line } from 'react-chartjs-2';

export function BudgetWidget() {
  const projets = useProjetStore((state) => state.projets);

  const budgetTotal = projets.reduce((sum, p) => sum + p.budgetActualise, 0);
  const subsidesTotal = projets.reduce((sum, p) => sum + (p.subside.actif ? p.subside.montant : 0), 0);
  const tauxCouverture = (subsidesTotal / budgetTotal) * 100;

  const budgetParMois = projets.reduce((acc, projet) => {
    const mois = new Date(projet.dateCreation).toISOString().slice(0, 7);
    acc[mois] = (acc[mois] || 0) + projet.budgetActualise;
    return acc;
  }, {});

  const chartData = {
    labels: Object.keys(budgetParMois),
    datasets: [{
      label: 'Budget mensuel',
      data: Object.values(budgetParMois),
      borderColor: '#1B4332',
      fill: false
    }]
  };

  return (
    <div>
      <h3 className="text-lg font-medium mb-4 flex items-center">
        <DollarSign className="h-5 w-5 mr-2" />
        Aperçu budgétaire
      </h3>

      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="p-4 bg-gray-50 rounded-lg">
          <p className="text-sm text-gray-600">Budget total</p>
          <p className="text-xl font-bold text-[#1B4332]">
            {formatMontant(budgetTotal)}
          </p>
        </div>
        <div className="p-4 bg-gray-50 rounded-lg">
          <p className="text-sm text-gray-600">Total subsides</p>
          <p className="text-xl font-bold text-[#9B2242]">
            {formatMontant(subsidesTotal)}
          </p>
        </div>
        <div className="p-4 bg-gray-50 rounded-lg">
          <p className="text-sm text-gray-600">Taux de couverture</p>
          <p className="text-xl font-bold text-gray-900">
            {tauxCouverture.toFixed(1)}%
          </p>
        </div>
      </div>

      <div className="h-64">
        <Line 
          data={chartData}
          options={{
            responsive: true,
            maintainAspectRatio: false,
            scales: {
              y: {
                beginAtZero: true,
                ticks: {
                  callback: (value) => formatMontant(value as number)
                }
              }
            }
          }}
        />
      </div>
    </div>
  );
}