import React from 'react';
import { DashboardWidget } from '../../types/dashboard';
import { ProjetsRecents } from './widgets/ProjetsRecents';
import { Favoris } from './widgets/Favoris';
import { Alertes } from './widgets/Alertes';
import { StatistiquesWidget } from './widgets/StatistiquesWidget';
import { CalendrierWidget } from './widgets/CalendrierWidget';
import { BudgetWidget } from './widgets/BudgetWidget';
import { RisquesWidget } from './widgets/RisquesWidget';
import { NotificationsWidget } from './widgets/NotificationsWidget';

interface WidgetContainerProps {
  widget: DashboardWidget;
}

export function WidgetContainer({ widget }: WidgetContainerProps) {
  if (!widget.visible) return null;

  const renderWidget = () => {
    switch (widget.type) {
      case 'projets-recents':
        return <ProjetsRecents />;
      case 'favoris':
        return <Favoris />;
      case 'alertes':
        return <Alertes />;
      case 'statistiques':
        return <StatistiquesWidget />;
      case 'calendrier':
        return <CalendrierWidget />;
      case 'budget':
        return <BudgetWidget />;
      case 'risques':
        return <RisquesWidget />;
      case 'notifications':
        return <NotificationsWidget />;
      default:
        return null;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
      {renderWidget()}
    </div>
  );
}