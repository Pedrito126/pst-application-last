import React from 'react';
import { Settings, DragHandleDots2Icon } from 'lucide-react';
import { useDashboardStore } from '../../store/dashboardStore';
import { DashboardWidget } from '../../types/dashboard';
import { useAuthStore } from '../../store/authStore';

export function ConfigurationDashboard() {
  const user = useAuthStore((state) => state.user);
  const { getConfig, updateConfig, toggleWidget, reorderWidgets } = useDashboardStore();

  if (!user) return null;

  const config = getConfig(user.id);

  const handleToggleWidget = (widgetId: string) => {
    toggleWidget(user.id, widgetId);
  };

  const handleReorder = (ordreWidgets: string[]) => {
    reorderWidgets(user.id, ordreWidgets);
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg mb-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-medium flex items-center">
          <Settings className="h-5 w-5 mr-2" />
          Configuration du tableau de bord
        </h2>
      </div>

      <div className="space-y-4">
        {config.widgets.map((widget) => (
          <div
            key={widget.id}
            className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
          >
            <div className="flex items-center">
              <DragHandleDots2Icon className="h-5 w-5 text-gray-400 mr-3 cursor-move" />
              <span className="font-medium">{getWidgetLabel(widget.type)}</span>
            </div>
            <div className="flex items-center space-x-4">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={widget.visible}
                  onChange={() => handleToggleWidget(widget.id)}
                  className="rounded border-gray-300 text-[#1B4332] focus:ring-[#1B4332]"
                />
                <span className="ml-2 text-sm text-gray-600">Visible</span>
              </label>
            </div>
          </div>
        ))}
      </div>

      <p className="mt-4 text-sm text-gray-500">
        Faites glisser les widgets pour réorganiser votre tableau de bord
      </p>
    </div>
  );
}

function getWidgetLabel(type: DashboardWidget['type']): string {
  const labels: Record<DashboardWidget['type'], string> = {
    'projets-recents': 'Projets récents',
    'favoris': 'Favoris',
    'alertes': 'Alertes',
    'statistiques': 'Statistiques',
    'calendrier': 'Calendrier',
    'budget': 'Budget',
    'risques': 'Risques',
    'notifications': 'Notifications'
  };
  return labels[type];
}