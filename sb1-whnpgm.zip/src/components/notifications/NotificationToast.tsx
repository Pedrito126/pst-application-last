import React from 'react';
import { X, CheckCircle, AlertCircle, Info, AlertTriangle } from 'lucide-react';

interface NotificationToastProps {
  type: 'success' | 'error' | 'info' | 'warning';
  message: string;
  onClose: () => void;
}

export function NotificationToast({ type, message, onClose }: NotificationToastProps) {
  const getIcon = () => {
    switch (type) {
      case 'success':
        return <CheckCircle className="h-5 w-5 text-green-400" />;
      case 'error':
        return <AlertCircle className="h-5 w-5 text-red-400" />;
      case 'info':
        return <Info className="h-5 w-5 text-blue-400" />;
      case 'warning':
        return <AlertTriangle className="h-5 w-5 text-yellow-400" />;
    }
  };

  const getStyles = () => {
    const baseStyles = 'rounded-lg p-4 flex items-start shadow-lg max-w-sm w-full';
    switch (type) {
      case 'success':
        return `${baseStyles} bg-green-50 border border-green-100`;
      case 'error':
        return `${baseStyles} bg-red-50 border border-red-100`;
      case 'info':
        return `${baseStyles} bg-blue-50 border border-blue-100`;
      case 'warning':
        return `${baseStyles} bg-yellow-50 border border-yellow-100`;
    }
  };

  return (
    <div className={getStyles()}>
      <div className="flex-shrink-0">{getIcon()}</div>
      <div className="ml-3 w-0 flex-1">
        <p className="text-sm font-medium text-gray-900">{message}</p>
      </div>
      <div className="ml-4 flex-shrink-0 flex">
        <button
          className="bg-transparent rounded-md inline-flex text-gray-400 hover:text-gray-500 focus:outline-none"
          onClick={onClose}
        >
          <X className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
}