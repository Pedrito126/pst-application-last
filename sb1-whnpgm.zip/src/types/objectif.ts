import { Volet } from './projet';

export interface ObjectifStrategique {
  id: string;
  code: string;
  titre: string;
  description: string;
  volet: Volet;
}

export interface ObjectifOperationnel {
  id: string;
  code: string;
  titre: string;
  description: string;
  objectifStrategiqueId: string;
}