export type WidgetType = 
  | 'projets-recents'
  | 'favoris'
  | 'alertes'
  | 'statistiques'
  | 'calendrier'
  | 'budget'
  | 'risques'
  | 'notifications';

export interface DashboardWidget {
  id: string;
  type: WidgetType;
  position: number;
  visible: boolean;
  settings?: Record<string, any>;
}

export interface DashboardConfig {
  userId: string;
  widgets: DashboardWidget[];
  favoris: string[];
  vuePersonnalisee?: {
    filtres: Record<string, any>;
    colonnes: string[];
  };
}

export interface Notification {
  id: string;
  type: 'info' | 'warning' | 'success' | 'error';
  titre: string;
  message: string;
  date: string;
  lue: boolean;
  lienProjet?: string;
  importance: 'basse' | 'moyenne' | 'haute';
}

export interface Risque {
  id: string;
  projetId: string;
  description: string;
  probabilite: 1 | 2 | 3 | 4 | 5;
  impact: 1 | 2 | 3 | 4 | 5;
  statut: 'identifie' | 'en-cours' | 'mitige' | 'realise';
  planMitigation?: string;
  dateIdentification: string;
  dateMiseAJour: string;
  responsable: string;
}

export interface Commentaire {
  id: string;
  projetId: string;
  auteur: string;
  message: string;
  date: string;
  reponses: Commentaire[];
  mentions: string[];
}

export interface Reunion {
  id: string;
  titre: string;
  description: string;
  date: string;
  duree: number;
  participants: string[];
  projetId?: string;
  documentsPrepares: string[];
  compteRendu?: string;
  statut: 'planifiee' | 'terminee' | 'annulee';
}