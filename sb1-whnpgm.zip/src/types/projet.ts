import { Volet } from './objectif';

export type EtatProjet = 'BROUILLON' | 'NON_DEMARRE' | 'EN_COURS' | 'TERMINE' | 'BLOQUE';
export type Priorite = 'P1' | 'P2' | 'P3';

export interface Projet {
  id: string;
  titre: string;
  description: string;
  etat: EtatProjet;
  refDPC: string;
  volet: Volet;
  objectifStrategique: string;
  objectifOperationnel: string;
  refODD: number;
  budgetActualise: number;
  subside: {
    actif: boolean;
    montant: number;
  };
  chefProjet: string[];
  agentPartenaire: string[];
  partenaireExterne: string[];
  echevinReferent: string[];
  priorite: Priorite;
  conditionsContraintes: string;
  realisation?: string;
  dateCreation: string;
  dateMiseAJour: string;
  reference: string;
  isTest?: boolean;
  version: number;
  historique: VersionProjet[];
  projetsLies: string[];
}

export interface VersionProjet {
  version: number;
  date: string;
  auteur: string;
  modifications: string[];
  commentaire?: string;
}

export interface FiltresProjet {
  etat?: EtatProjet;
  volet?: Volet;
  priorite?: Priorite;
  periode?: {
    debut: Date;
    fin: Date;
  };
  recherche?: string;
}