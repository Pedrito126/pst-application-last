export type UserRole = 'ADMIN' | 'DG' | 'DF' | 'USER' | 'ECHEVIN' | 'SAG';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  active?: boolean;
}

export interface UserFormData {
  email: string;
  name: string;
  role: UserRole;
  password: string;
}