export type TypeAnnexe = 'image' | 'document' | 'pdf' | 'office' | 'lien';
export type CategorieAnnexe = 'documentation' | 'technique' | 'administratif' | 'financier' | 'autre';

export interface Annexe {
  id: string;
  projetId: string;
  nom: string;
  type: TypeAnnexe;
  url: string;
  dateAjout: string;
  taille?: number;
  categorie: CategorieAnnexe;
  tags: string[];
  version: number;
  historique: VersionAnnexe[];
  dossier?: string;
}

export interface VersionAnnexe {
  version: number;
  date: string;
  auteur: string;
  commentaire?: string;
  url: string;
}

export interface DossierAnnexe {
  id: string;
  nom: string;
  projetId: string;
  parent?: string;
  dateCreation: string;
}