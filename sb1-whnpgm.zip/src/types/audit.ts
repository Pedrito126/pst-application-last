export type ActionType = 
  | 'CREATION_PROJET'
  | 'MODIFICATION_PROJET'
  | 'SUPPRESSION_PROJET'
  | 'CONNEXION'
  | 'DECONNEXION'
  | 'CREATION_COMPTE';

export interface AuditLog {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  userRole: string;
  actionType: ActionType;
  details: {
    projetId?: string;
    projetTitre?: string;
    modifications?: Record<string, any>;
  };
}