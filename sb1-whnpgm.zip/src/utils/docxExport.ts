import { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, HeadingLevel, AlignmentType } from 'docx';
import { Projet, FiltresProjet } from '../types/projet';
import { formatDate, formatMontant } from './formatters';
import { saveAs } from 'file-saver';

export const exportProjetsDocx = async (projets: Projet[], filtres: FiltresProjet) => {
  const doc = new Document({
    sections: [{
      properties: {},
      children: [
        new Paragraph({
          text: "Liste des Projets PST",
          heading: HeadingLevel.HEADING_1,
          alignment: AlignmentType.CENTER,
        }),
        
        // Filtres appliqués
        new Paragraph({
          text: "Filtres appliqués:",
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 400 },
        }),
        
        // Tableau des projets
        new Table({
          width: {
            size: 100,
            type: "pct",
          },
          rows: [
            // En-tête
            new TableRow({
              children: [
                "Référence",
                "Titre",
                "État",
                "Budget",
                "Mise à jour"
              ].map(text => new TableCell({
                children: [new Paragraph({ text, bold: true })],
              })),
            }),
            // Données
            ...projets.map(projet => new TableRow({
              children: [
                new TableCell({
                  children: [new Paragraph({ text: projet.reference })],
                }),
                new TableCell({
                  children: [new Paragraph({ text: projet.titre })],
                }),
                new TableCell({
                  children: [new Paragraph({ text: projet.etat.replace('_', ' ') })],
                }),
                new TableCell({
                  children: [new Paragraph({ text: formatMontant(projet.budgetActualise) })],
                }),
                new TableCell({
                  children: [new Paragraph({ text: formatDate(projet.dateMiseAJour) })],
                }),
              ],
            })),
          ],
        }),
        
        // Statistiques
        new Paragraph({
          text: "Statistiques",
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 400 },
        }),
        new Paragraph({
          children: [
            new TextRun({
              text: `Nombre total de projets: ${projets.length}`,
              bold: true,
            }),
          ],
        }),
        new Paragraph({
          children: [
            new TextRun({
              text: `Budget total: ${formatMontant(
                projets.reduce((sum, p) => sum + p.budgetActualise, 0)
              )}`,
              bold: true,
            }),
          ],
        }),
        
        // Pied de page
        new Paragraph({
          text: "Proudly made by Pedro Sevilla - GestionPST 2024",
          alignment: AlignmentType.CENTER,
          spacing: { before: 400 },
        }),
      ],
    }],
  });

  const blob = await Packer.toBlob(doc);
  saveAs(blob, "projets-pst.docx");
};