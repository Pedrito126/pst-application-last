export const backupInstructions = `
Instructions pour sauvegarder l'application PST

1. Sauvegarde des données
-------------------------
- Connectez-vous en tant qu'administrateur
- Allez dans la section "Liste des projets" (menu administrateur)
- Cliquez sur "Exporter les données"
- Un fichier JSON contenant toutes les données sera téléchargé
- Conservez ce fichier dans un endroit sûr

2. Documentation
---------------
- Dans la même section, cliquez sur "Exporter la documentation"
- Le manuel utilisateur sera téléchargé au format Word
- Vous pouvez modifier ce document selon vos besoins

3. Bonnes pratiques
------------------
- Effectuez une sauvegarde régulière (au moins mensuelle)
- Conservez plusieurs versions des sauvegardes
- Stockez les sauvegardes sur plusieurs supports
- Vérifiez périodiquement que vous pouvez ouvrir les fichiers
- Documentez les modifications apportées à l'application

4. Sécurité
-----------
- Protégez les fichiers de sauvegarde par mot de passe
- Ne partagez pas les sauvegardes avec des personnes non autorisées
- Conservez une copie hors-ligne des données
- Respectez le RGPD dans la gestion des données

5. En cas de problème
--------------------
- Conservez une trace des modifications effectuées
- Notez la date et l'heure des sauvegardes
- Gardez un historique des versions
- Documentez les procédures de restauration

Cette application a été développée pour la gestion du Plan Stratégique Transversal.
Version: 1.0.0
`;