import { ObjectifStrategique, ObjectifOperationnel } from '../types/objectif';

export function generateOSCode(volet: 'INTERNE' | 'EXTERNE', existingCodes: string[]): string {
  const prefix = volet === 'INTERNE' ? 'OS.I.' : 'OS.E.';
  const existingNumbers = existingCodes
    .filter(code => code.startsWith(prefix))
    .map(code => parseInt(code.split('.').pop() || '0'));
  
  const nextNumber = Math.max(0, ...existingNumbers) + 1;
  return `${prefix}${nextNumber.toString().padStart(2, '0')}`;
}

export function generateOOCode(
  osCode: string,
  existingCodes: string[]
): string {
  const prefix = `${osCode}.OO.`;
  const existingNumbers = existingCodes
    .filter(code => code.startsWith(prefix))
    .map(code => parseInt(code.split('.').pop() || '0'));
  
  const nextNumber = Math.max(0, ...existingNumbers) + 1;
  return `${prefix}${nextNumber.toString().padStart(2, '0')}`;
}

export function generateProjetReference(
  volet: 'INTERNE' | 'EXTERNE',
  osCode: string,
  ooCode: string,
  existingRefs: string[]
): string {
  const prefix = volet === 'INTERNE' ? 'VI' : 'VE';
  const osNumber = osCode.split('.').pop() || '00';
  const ooNumber = ooCode.split('.').pop() || '00';
  
  const baseRef = `${prefix}${osNumber}${ooNumber}`;
  const existingNumbers = existingRefs
    .filter(ref => ref.startsWith(baseRef))
    .map(ref => parseInt(ref.split('-')[1] || '0'));
  
  const nextNumber = Math.max(0, ...existingNumbers) + 1;
  return `${baseRef}-${nextNumber.toString().padStart(2, '0')}`;
}