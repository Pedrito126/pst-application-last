import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Projet } from '../types/projet';
import { formatDate, formatMontant } from './formatters';
import { ODD } from '../config/auth';

export const generateProjetPDF = (projet: Projet) => {
  const doc = new jsPDF();
  
  // En-tête
  doc.addImage('/logo-ittre.svg', 'SVG', 10, 10, 30, 30);
  doc.setFontSize(20);
  doc.text('Fiche Projet PST', 50, 25);
  
  // Informations principales
  doc.setFontSize(12);
  const oddInfo = ODD.find(o => o.id === projet.refODD);
  
  const info = [
    ['Référence', projet.reference],
    ['Titre', projet.titre],
    ['État', projet.etat],
    ['Volet', projet.volet],
    ['Priorité', projet.priorite],
    ['ODD', `${projet.refODD} - ${oddInfo?.titre || ''}`],
    ['Budget', formatMontant(projet.budgetActualise)],
    ['Date de création', formatDate(projet.dateCreation)],
    ['Dernière mise à jour', formatDate(projet.dateMiseAJour)]
  ];

  autoTable(doc, {
    startY: 50,
    head: [],
    body: info,
    theme: 'plain',
    styles: { fontSize: 10 },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 40 },
      1: { cellWidth: 'auto' }
    }
  });

  // Description
  doc.setFontSize(14);
  doc.text('Description', 14, doc.lastAutoTable.finalY + 10);
  doc.setFontSize(10);
  const splitDescription = doc.splitTextToSize(projet.description, 180);
  doc.text(splitDescription, 14, doc.lastAutoTable.finalY + 20);

  // Pied de page
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.text(
      'GestionPST 2024 - Créé par Pedro Sevilla - Tous droits réservés',
      14,
      doc.internal.pageSize.height - 10
    );
  }

  return doc;
};