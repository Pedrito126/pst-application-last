export const formatReference = (
  volet: 'INTERNE' | 'EXTERNE',
  odd: number,
  objectifStrategique: string,
  objectifOperationnel: string,
  numeroFiche: number
): string => {
  const prefixe = volet === 'INTERNE' ? 'VI' : 'VO';
  const oddFormate = odd.toString().padStart(2, '0');
  const osFormate = objectifStrategique.padStart(2, '0');
  const ooFormate = objectifOperationnel.padStart(2, '0');
  
  return `${prefixe}${oddFormate}${osFormate}${ooFormate}-${numeroFiche}`;
};

export const formatMontant = (montant: number): string => {
  return new Intl.NumberFormat('fr-BE', {
    style: 'currency',
    currency: 'EUR',
  }).format(montant);
};

export const formatDate = (date: string): string => {
  return new Date(date).toLocaleDateString('fr-BE', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  });
};