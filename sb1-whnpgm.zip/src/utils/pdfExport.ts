import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Projet, FiltresProjet } from '../types/projet';
import { formatDate, formatMontant } from './formatters';
import { ODD } from '../config/auth';

export const exportProjetsPDF = (projets: Projet[], filtres: FiltresProjet) => {
  const doc = new jsPDF();

  // En-tête
  doc.addImage('/logo-ittre.svg', 'SVG', 10, 10, 30, 30);
  doc.setFontSize(20);
  doc.text('Liste des Projets PST', 50, 25);

  // Informations sur les filtres
  doc.setFontSize(12);
  let y = 40;
  doc.text('Filtres appliqués:', 14, y);
  y += 7;

  if (filtres.etat) {
    doc.text(`État: ${filtres.etat.replace('_', ' ')}`, 20, y);
    y += 7;
  }
  if (filtres.volet) {
    doc.text(`Volet: ${filtres.volet}`, 20, y);
    y += 7;
  }
  if (filtres.priorite) {
    doc.text(`Priorité: ${filtres.priorite}`, 20, y);
    y += 7;
  }
  if (filtres.periode) {
    doc.text(
      `Période: du ${formatDate(filtres.periode.debut.toISOString())} au ${formatDate(
        filtres.periode.fin.toISOString()
      )}`,
      20,
      y
    );
    y += 7;
  }

  // Tableau des projets
  const tableData = projets.map((projet) => [
    projet.reference,
    projet.titre,
    projet.etat.replace('_', ' '),
    projet.volet,
    projet.priorite,
    formatDate(projet.dateMiseAJour),
    formatMontant(projet.budgetActualise),
  ]);

  autoTable(doc, {
    startY: y + 10,
    head: [
      [
        'Référence',
        'Titre',
        'État',
        'Volet',
        'Priorité',
        'Mise à jour',
        'Budget',
      ],
    ],
    body: tableData,
    styles: { fontSize: 8 },
    headStyles: { fillColor: [27, 67, 50] }, // Couleur Ittre
  });

  // Statistiques
  const totalProjets = projets.length;
  const totalBudget = projets.reduce((sum, p) => sum + p.budgetActualise, 0);
  const totalSubsides = projets.reduce(
    (sum, p) => sum + (p.subside.actif ? p.subside.montant : 0),
    0
  );

  doc.addPage();
  doc.setFontSize(16);
  doc.text('Statistiques', 14, 20);

  const stats = [
    ['Nombre total de projets', totalProjets.toString()],
    ['Budget total', formatMontant(totalBudget)],
    ['Total des subsides', formatMontant(totalSubsides)],
  ];

  autoTable(doc, {
    startY: 30,
    head: [],
    body: stats,
    theme: 'plain',
    styles: { fontSize: 10 },
  });

  // Pied de page
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.text(
      'Proudly made by Pedro Sevilla - GestionPST 2024',
      14,
      doc.internal.pageSize.height - 10
    );
  }

  return doc;
};