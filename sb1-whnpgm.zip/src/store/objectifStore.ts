import { create } from 'zustand';
import { ObjectifStrategique, ObjectifOperationnel } from '../types/objectif';
import { useAuditStore } from './auditStore';

interface ObjectifState {
  objectifsStrategiques: ObjectifStrategique[];
  objectifsOperationnels: ObjectifOperationnel[];
  ajouterObjectifStrategique: (objectif: Omit<ObjectifStrategique, 'id'>) => string;
  ajouterObjectifOperationnel: (objectif: Omit<ObjectifOperationnel, 'id'>) => string;
  modifierObjectifStrategique: (id: string, objectif: Partial<ObjectifStrategique>) => void;
  modifierObjectifOperationnel: (id: string, objectif: Partial<ObjectifOperationnel>) => void;
  supprimerObjectifStrategique: (id: string) => void;
  supprimerObjectifOperationnel: (id: string) => void;
  getObjectifsOperationnels: (objectifStrategiqueId: string) => ObjectifOperationnel[];
  setObjectifsStrategiques: (objectifs: ObjectifStrategique[]) => void;
  setObjectifsOperationnels: (objectifs: ObjectifOperationnel[]) => void;
}

// Données de test initiales
const objectifsStrategiquesInitiaux: ObjectifStrategique[] = [
  {
    id: 'os-1',
    code: 'OS.I.01',
    titre: 'Être une administration moderne au service du citoyen',
    description: 'Modernisation des services et amélioration de la qualité',
    volet: 'INTERNE'
  },
  {
    id: 'os-2',
    code: 'OS.E.01',
    titre: 'Développer une politique de développement durable',
    description: 'Actions en faveur du développement durable',
    volet: 'EXTERNE'
  }
];

const objectifsOperationnelsInitiaux: ObjectifOperationnel[] = [
  {
    id: 'oo-1-1',
    code: 'OS.I.01.OO.01',
    titre: 'Moderniser les outils de travail',
    description: 'Mise à jour des équipements et logiciels',
    objectifStrategiqueId: 'os-1'
  },
  {
    id: 'oo-1-2',
    code: 'OS.I.01.OO.02',
    titre: 'Améliorer l\'accueil des citoyens',
    description: 'Optimisation des services d\'accueil',
    objectifStrategiqueId: 'os-1'
  },
  {
    id: 'oo-2-1',
    code: 'OS.E.01.OO.01',
    titre: 'Réduire l\'empreinte carbone',
    description: 'Actions pour la réduction des émissions de CO2',
    objectifStrategiqueId: 'os-2'
  }
];

export const useObjectifStore = create<ObjectifState>((set, get) => ({
  objectifsStrategiques: objectifsStrategiquesInitiaux,
  objectifsOperationnels: objectifsOperationnelsInitiaux,
  
  setObjectifsStrategiques: (objectifs) => {
    set({ objectifsStrategiques: objectifs });
  },

  setObjectifsOperationnels: (objectifs) => {
    set({ objectifsOperationnels: objectifs });
  },

  ajouterObjectifStrategique: (objectif) => {
    const id = crypto.randomUUID();
    set((state) => ({
      objectifsStrategiques: [...state.objectifsStrategiques, { ...objectif, id }],
    }));
    useAuditStore.getState().addLog('CREATION_OBJECTIF_STRATEGIQUE', {
      objectifId: id,
      objectifTitre: objectif.titre,
    });
    return id;
  },

  ajouterObjectifOperationnel: (objectif) => {
    const id = crypto.randomUUID();
    set((state) => ({
      objectifsOperationnels: [...state.objectifsOperationnels, { ...objectif, id }],
    }));
    useAuditStore.getState().addLog('CREATION_OBJECTIF_OPERATIONNEL', {
      objectifId: id,
      objectifTitre: objectif.titre,
    });
    return id;
  },

  modifierObjectifStrategique: (id, modifications) => {
    set((state) => ({
      objectifsStrategiques: state.objectifsStrategiques.map((os) =>
        os.id === id ? { ...os, ...modifications } : os
      ),
    }));
    useAuditStore.getState().addLog('MODIFICATION_OBJECTIF_STRATEGIQUE', {
      objectifId: id,
      modifications,
    });
  },

  modifierObjectifOperationnel: (id, modifications) => {
    set((state) => ({
      objectifsOperationnels: state.objectifsOperationnels.map((oo) =>
        oo.id === id ? { ...oo, ...modifications } : oo
      ),
    }));
    useAuditStore.getState().addLog('MODIFICATION_OBJECTIF_OPERATIONNEL', {
      objectifId: id,
      modifications,
    });
  },

  supprimerObjectifStrategique: (id) => {
    const objectif = get().objectifsStrategiques.find((os) => os.id === id);
    set((state) => ({
      objectifsStrategiques: state.objectifsStrategiques.filter((os) => os.id !== id),
      objectifsOperationnels: state.objectifsOperationnels.filter(
        (oo) => oo.objectifStrategiqueId !== id
      ),
    }));
    useAuditStore.getState().addLog('SUPPRESSION_OBJECTIF_STRATEGIQUE', {
      objectifId: id,
      objectifTitre: objectif?.titre,
    });
  },

  supprimerObjectifOperationnel: (id) => {
    const objectif = get().objectifsOperationnels.find((oo) => oo.id === id);
    set((state) => ({
      objectifsOperationnels: state.objectifsOperationnels.filter((oo) => oo.id !== id),
    }));
    useAuditStore.getState().addLog('SUPPRESSION_OBJECTIF_OPERATIONNEL', {
      objectifId: id,
      objectifTitre: objectif?.titre,
    });
  },

  getObjectifsOperationnels: (objectifStrategiqueId) => {
    return get().objectifsOperationnels.filter(
      (oo) => oo.objectifStrategiqueId === objectifStrategiqueId
    );
  },
}));