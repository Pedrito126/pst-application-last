import { create } from 'zustand';
import { Annexe } from '../types/annexe';

interface AnnexeState {
  annexes: Record<string, Annexe[]>;
  ajouterAnnexe: (annexe: Annexe) => void;
  supprimerAnnexe: (projetId: string, annexeId: string) => void;
  getAnnexesProjet: (projetId: string) => Annexe[];
}

export const useAnnexeStore = create<AnnexeState>((set, get) => ({
  annexes: {},
  ajouterAnnexe: (annexe) => {
    set((state) => {
      const projetAnnexes = state.annexes[annexe.projetId] || [];
      return {
        annexes: {
          ...state.annexes,
          [annexe.projetId]: [...projetAnnexes, annexe],
        },
      };
    });
  },
  supprimerAnnexe: (projetId, annexeId) => {
    set((state) => {
      const projetAnnexes = state.annexes[projetId] || [];
      return {
        annexes: {
          ...state.annexes,
          [projetId]: projetAnnexes.filter((a) => a.id !== annexeId),
        },
      };
    });
  },
  getAnnexesProjet: (projetId) => {
    return get().annexes[projetId] || [];
  },
}));