import { create } from 'zustand';
import { ObjectifStrategique, ObjectifOperationnel } from '../types/objectif';
import { Projet } from '../types/projet';
import { useProjetStore } from './projetStore';
import { useObjectifStore } from './objectifStore';

interface TestDataState {
  objectifsStrategiques: ObjectifStrategique[];
  objectifsOperationnels: ObjectifOperationnel[];
  projets: Projet[];
  clearTestData: () => void;
  generateTestData: () => void;
}

const PREFIX = '[TEST] ';

const generateTestObjectifs = () => {
  const objectifsStrategiques: ObjectifStrategique[] = [
    {
      id: 'test-os-1',
      code: 'OS.I.01',
      titre: PREFIX + 'Être une administration moderne au service du citoyen',
      description: 'Modernisation des services et amélioration de la qualité',
      volet: 'INTERNE'
    },
    {
      id: 'test-os-2',
      code: 'OS.E.01',
      titre: PREFIX + 'Développer une politique de développement durable',
      description: 'Actions en faveur du développement durable',
      volet: 'EXTERNE'
    }
  ];

  const objectifsOperationnels: ObjectifOperationnel[] = [
    {
      id: 'test-oo-1-1',
      code: 'OS.I.01.OO.01',
      titre: PREFIX + 'Moderniser les outils de travail',
      description: 'Mise à jour des équipements et logiciels',
      objectifStrategiqueId: 'test-os-1'
    },
    {
      id: 'test-oo-1-2',
      code: 'OS.I.01.OO.02',
      titre: PREFIX + 'Améliorer l\'accueil des citoyens',
      description: 'Optimisation des services d\'accueil',
      objectifStrategiqueId: 'test-os-1'
    },
    {
      id: 'test-oo-2-1',
      code: 'OS.E.01.OO.01',
      titre: PREFIX + 'Réduire l\'empreinte carbone',
      description: 'Actions pour la réduction des émissions de CO2',
      objectifStrategiqueId: 'test-os-2'
    }
  ];

  return { objectifsStrategiques, objectifsOperationnels };
};

const generateTestProjets = (): Projet[] => [
  {
    id: 'test-p-1',
    titre: PREFIX + 'Digitalisation des services communaux',
    description: 'Modernisation des outils informatiques et dématérialisation des procédures',
    etat: 'EN_COURS',
    refDPC: 'DPC.1.1',
    volet: 'INTERNE',
    objectifStrategique: 'test-os-1',
    objectifOperationnel: 'test-oo-1-1',
    refODD: 9,
    budgetActualise: 75000,
    subside: {
      actif: true,
      montant: 45000
    },
    chefProjet: ['test-user-1'],
    agentPartenaire: ['test-user-2'],
    partenaireExterne: [],
    echevinReferent: ['test-echevin-1'],
    priorite: 'P1',
    conditionsContraintes: 'Formation du personnel nécessaire',
    dateCreation: '2024-01-15T10:00:00.000Z',
    dateMiseAJour: '2024-03-24T14:30:00.000Z',
    reference: 'VI010101-1',
    isTest: true,
    version: 1,
    historique: [],
    projetsLies: []
  },
  {
    id: 'test-p-2',
    titre: PREFIX + 'Installation de panneaux solaires',
    description: 'Installation de panneaux photovoltaïques sur les bâtiments communaux',
    etat: 'BROUILLON',
    refDPC: 'DPC.2.1',
    volet: 'EXTERNE',
    objectifStrategique: 'test-os-2',
    objectifOperationnel: 'test-oo-2-1',
    refODD: 7,
    budgetActualise: 150000,
    subside: {
      actif: true,
      montant: 90000
    },
    chefProjet: ['test-user-3'],
    agentPartenaire: ['test-user-4'],
    partenaireExterne: ['Entreprise Solar'],
    echevinReferent: ['test-echevin-2'],
    priorite: 'P2',
    conditionsContraintes: 'Étude de faisabilité requise',
    dateCreation: '2024-03-01T10:00:00.000Z',
    dateMiseAJour: '2024-03-24T14:30:00.000Z',
    reference: 'VE010101-1',
    isTest: true,
    version: 1,
    historique: [],
    projetsLies: []
  }
];

export const useTestDataStore = create<TestDataState>((set) => ({
  objectifsStrategiques: [],
  objectifsOperationnels: [],
  projets: [],

  clearTestData: () => {
    const projetStore = useProjetStore.getState();
    const objectifStore = useObjectifStore.getState();

    // Supprimer les projets de test
    projetStore.setProjets(
      projetStore.projets.filter(p => !p.isTest)
    );

    // Supprimer les objectifs de test
    objectifStore.setObjectifsStrategiques(
      objectifStore.objectifsStrategiques.filter(os => !os.titre.startsWith(PREFIX))
    );
    objectifStore.setObjectifsOperationnels(
      objectifStore.objectifsOperationnels.filter(oo => !oo.titre.startsWith(PREFIX))
    );

    set({
      objectifsStrategiques: [],
      objectifsOperationnels: [],
      projets: []
    });
  },

  generateTestData: () => {
    const { objectifsStrategiques, objectifsOperationnels } = generateTestObjectifs();
    const projets = generateTestProjets();

    const projetStore = useProjetStore.getState();
    const objectifStore = useObjectifStore.getState();

    // Ajouter les objectifs de test
    objectifStore.setObjectifsStrategiques([
      ...objectifStore.objectifsStrategiques,
      ...objectifsStrategiques
    ]);
    objectifStore.setObjectifsOperationnels([
      ...objectifStore.objectifsOperationnels,
      ...objectifsOperationnels
    ]);

    // Ajouter les projets de test
    projetStore.setProjets([
      ...projetStore.projets,
      ...projets
    ]);

    set({
      objectifsStrategiques,
      objectifsOperationnels,
      projets
    });
  }
}));