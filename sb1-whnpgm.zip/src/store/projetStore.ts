import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Projet } from '../types/projet';
import { generateProjetReference } from '../utils/codeGenerator';

interface ProjetState {
  projets: Projet[];
  filtres: Record<string, any>;
  projetSelectionne: Projet | null;
  setProjets: (projets: Projet[]) => void;
  ajouterProjet: (projet: Projet) => void;
  modifierProjet: (id: string, projet: Projet) => void;
  supprimerProjet: (id: string) => void;
  dupliquerProjet: (id: string, options: { conserverLiens: boolean; conserverAnnexes: boolean }) => void;
  setFiltres: (filtres: Record<string, any>) => void;
  setProjetSelectionne: (projet: Projet | null) => void;
}

export const useProjetStore = create<ProjetState>()(
  persist(
    (set, get) => ({
      projets: [],
      filtres: {},
      projetSelectionne: null,

      setProjets: (projets) => set({ projets }),

      ajouterProjet: (projet) => 
        set((state) => ({ projets: [...state.projets, projet] })),

      modifierProjet: (id, projetModifie) =>
        set((state) => ({
          projets: state.projets.map((p) => 
            p.id === id ? projetModifie : p
          ),
        })),

      supprimerProjet: (id) =>
        set((state) => ({
          projets: state.projets.filter((p) => p.id !== id),
        })),

      dupliquerProjet: (id, options) => {
        const projetOriginal = get().projets.find(p => p.id === id);
        if (!projetOriginal) return;

        const nouveauProjet = {
          ...projetOriginal,
          id: crypto.randomUUID(),
          titre: `Copie de ${projetOriginal.titre}`,
          reference: generateProjetReference(
            projetOriginal.volet,
            projetOriginal.objectifStrategique,
            projetOriginal.objectifOperationnel,
            get().projets.map(p => p.reference)
          ),
          dateCreation: new Date().toISOString(),
          dateMiseAJour: new Date().toISOString(),
          etat: 'BROUILLON',
          version: 1,
          historique: [],
          projetsLies: options.conserverLiens ? projetOriginal.projetsLies : []
        };

        set((state) => ({
          projets: [...state.projets, nouveauProjet]
        }));

        return nouveauProjet.id;
      },

      setFiltres: (filtres) => set({ filtres }),
      
      setProjetSelectionne: (projet) => set({ projetSelectionne: projet }),
    }),
    {
      name: 'projet-storage',
      partialize: (state) => ({
        projets: state.projets,
      }),
    }
  )
);