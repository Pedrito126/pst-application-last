import { create } from 'zustand';
import { AuditLog, ActionType } from '../types/audit';
import { useAuthStore } from './authStore';

interface AuditState {
  logs: AuditLog[];
  addLog: (actionType: ActionType, details?: AuditLog['details']) => void;
  getLogs: (filters?: {
    startDate?: Date;
    endDate?: Date;
    userId?: string;
    actionType?: ActionType;
  }) => AuditLog[];
}

export const useAuditStore = create<AuditState>((set, get) => ({
  logs: [],
  addLog: (actionType, details = {}) => {
    const user = useAuthStore.getState().user;
    if (!user) return;

    const newLog: AuditLog = {
      id: crypto.randomUUID(),
      timestamp: new Date().toISOString(),
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      actionType,
      details,
    };

    set((state) => ({
      logs: [...state.logs, newLog],
    }));
  },
  getLogs: (filters) => {
    let filteredLogs = [...get().logs];

    if (filters?.startDate) {
      filteredLogs = filteredLogs.filter(
        (log) => new Date(log.timestamp) >= filters.startDate!
      );
    }

    if (filters?.endDate) {
      filteredLogs = filteredLogs.filter(
        (log) => new Date(log.timestamp) <= filters.endDate!
      );
    }

    if (filters?.userId) {
      filteredLogs = filteredLogs.filter(
        (log) => log.userId === filters.userId
      );
    }

    if (filters?.actionType) {
      filteredLogs = filteredLogs.filter(
        (log) => log.actionType === filters.actionType
      );
    }

    return filteredLogs.sort(
      (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
  },
}));