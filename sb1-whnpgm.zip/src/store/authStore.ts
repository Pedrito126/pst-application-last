import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { User, UserRole, UserFormData } from '../types/auth';

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  users: User[];
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  register: (userData: UserFormData) => Promise<boolean>;
  updateUserRole: (userId: string, role: UserRole) => void;
  updateUserStatus: (userId: string, active: boolean) => void;
  deleteUser: (userId: string) => void;
  getUsers: () => User[];
  canEditProject: (userId: string, projectChefs: string[], projectAgents: string[]) => boolean;
}

const initialUsers: User[] = [
  {
    id: '1',
    email: 'Admin',
    name: 'Administrateur',
    role: 'ADMIN',
    active: true
  },
  {
    id: '2',
    email: 'c.spaute@ittre.be',
    name: 'Carole Spaute',
    role: 'DG',
    active: true
  },
  {
    id: '3',
    email: 'c.delongueville@ittre.be',
    name: 'Catherine Delongueville',
    role: 'DF',
    active: true
  }
];

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,
      users: initialUsers,

      login: async (email: string, password: string) => {
        if (email === 'Admin' && password === 'W66@ufcKb-12') {
          set({ 
            user: initialUsers[0],
            isAuthenticated: true 
          });
          return true;
        }

        const user = get().users.find((u) => u.email === email && u.active);
        
        if (user) {
          set({ user, isAuthenticated: true });
          return true;
        }

        return false;
      },

      logout: () => {
        set({ user: null, isAuthenticated: false });
      },

      register: async (userData: UserFormData) => {
        const users = get().users;
        const existingUser = users.find((u) => u.email === userData.email);

        if (existingUser) {
          return false;
        }

        const newUser: User = {
          id: crypto.randomUUID(),
          email: userData.email,
          name: userData.name,
          role: userData.role,
          active: true
        };

        set((state) => ({
          users: [...state.users, newUser],
        }));

        return true;
      },

      updateUserRole: (userId: string, role: UserRole) => {
        set((state) => ({
          users: state.users.map((user) =>
            user.id === userId ? { ...user, role } : user
          ),
        }));
      },

      updateUserStatus: (userId: string, active: boolean) => {
        const currentUser = get().user;
        if (currentUser && currentUser.id === userId) {
          return;
        }

        set((state) => ({
          users: state.users.map((user) =>
            user.id === userId ? { ...user, active } : user
          ),
        }));
      },

      deleteUser: (userId: string) => {
        const currentUser = get().user;
        if (currentUser && currentUser.id === userId) {
          return;
        }

        set((state) => ({
          users: state.users.filter((user) => user.id !== userId),
        }));
      },

      getUsers: () => get().users,

      canEditProject: (userId: string, projectChefs: string[], projectAgents: string[]) => {
        const user = get().users.find(u => u.id === userId);
        if (!user) return false;

        if (['ADMIN', 'SAG'].includes(user.role)) return true;
        if (projectChefs.includes(userId)) return true;
        if (projectAgents.includes(userId)) return true;

        return false;
      }
    }),
    {
      name: 'auth-storage',
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        users: state.users,
      }),
    }
  )
);