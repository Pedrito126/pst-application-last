import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { DashboardConfig, DashboardWidget, Notification, Risque, Commentaire, Reunion } from '../types/dashboard';

interface DashboardState {
  configs: Record<string, DashboardConfig>;
  notifications: Notification[];
  risques: Risque[];
  commentaires: Record<string, Commentaire[]>;
  reunions: Reunion[];
  
  // Configuration du tableau de bord
  getConfig: (userId: string) => DashboardConfig;
  updateConfig: (userId: string, config: Partial<DashboardConfig>) => void;
  toggleWidget: (userId: string, widgetId: string) => void;
  reorderWidgets: (userId: string, ordreWidgets: string[]) => void;
  toggleFavori: (userId: string, projetId: string) => void;
  
  // Notifications
  addNotification: (notification: Omit<Notification, 'id' | 'date' | 'lue'>) => void;
  markNotificationAsRead: (notificationId: string) => void;
  deleteNotification: (notificationId: string) => void;
  
  // Risques
  addRisque: (risque: Omit<Risque, 'id' | 'dateIdentification' | 'dateMiseAJour'>) => void;
  updateRisque: (risqueId: string, updates: Partial<Risque>) => void;
  deleteRisque: (risqueId: string) => void;
  
  // Commentaires
  addCommentaire: (commentaire: Omit<Commentaire, 'id' | 'date' | 'reponses'>) => void;
  addReponse: (commentaireId: string, reponse: Omit<Commentaire, 'id' | 'date' | 'reponses'>) => void;
  deleteCommentaire: (commentaireId: string) => void;
  
  // Réunions
  addReunion: (reunion: Omit<Reunion, 'id'>) => void;
  updateReunion: (reunionId: string, updates: Partial<Reunion>) => void;
  deleteReunion: (reunionId: string) => void;
}

const defaultWidgets: DashboardWidget[] = [
  { id: 'projets-recents', type: 'projets-recents', position: 0, visible: true },
  { id: 'favoris', type: 'favoris', position: 1, visible: true },
  { id: 'alertes', type: 'alertes', position: 2, visible: true },
  { id: 'statistiques', type: 'statistiques', position: 3, visible: true },
  { id: 'calendrier', type: 'calendrier', position: 4, visible: true },
  { id: 'budget', type: 'budget', position: 5, visible: true },
  { id: 'risques', type: 'risques', position: 6, visible: true },
  { id: 'notifications', type: 'notifications', position: 7, visible: true },
];

export const useDashboardStore = create<DashboardState>()(
  persist(
    (set, get) => ({
      configs: {},
      notifications: [],
      risques: [],
      commentaires: {},
      reunions: [],

      getConfig: (userId) => {
        const config = get().configs[userId];
        if (!config) {
          return {
            userId,
            widgets: defaultWidgets,
            favoris: [],
          };
        }
        return config;
      },

      updateConfig: (userId, config) => {
        set((state) => ({
          configs: {
            ...state.configs,
            [userId]: {
              ...state.configs[userId],
              ...config,
            },
          },
        }));
      },

      toggleWidget: (userId, widgetId) => {
        set((state) => {
          const config = state.configs[userId];
          const widgets = config?.widgets.map(w =>
            w.id === widgetId ? { ...w, visible: !w.visible } : w
          );
          return {
            configs: {
              ...state.configs,
              [userId]: { ...config, widgets },
            },
          };
        });
      },

      reorderWidgets: (userId, ordreWidgets) => {
        set((state) => {
          const config = state.configs[userId];
          const widgets = config?.widgets.map((w, i) => ({
            ...w,
            position: ordreWidgets.indexOf(w.id),
          }));
          return {
            configs: {
              ...state.configs,
              [userId]: { ...config, widgets },
            },
          };
        });
      },

      toggleFavori: (userId, projetId) => {
        set((state) => {
          const config = state.configs[userId];
          const favoris = config?.favoris || [];
          const nouveauxFavoris = favoris.includes(projetId)
            ? favoris.filter(id => id !== projetId)
            : [...favoris, projetId];
          return {
            configs: {
              ...state.configs,
              [userId]: { ...config, favoris: nouveauxFavoris },
            },
          };
        });
      },

      addNotification: (notification) => {
        set((state) => ({
          notifications: [
            ...state.notifications,
            {
              ...notification,
              id: crypto.randomUUID(),
              date: new Date().toISOString(),
              lue: false,
            },
          ],
        }));
      },

      markNotificationAsRead: (notificationId) => {
        set((state) => ({
          notifications: state.notifications.map(n =>
            n.id === notificationId ? { ...n, lue: true } : n
          ),
        }));
      },

      deleteNotification: (notificationId) => {
        set((state) => ({
          notifications: state.notifications.filter(n => n.id !== notificationId),
        }));
      },

      addRisque: (risque) => {
        set((state) => ({
          risques: [
            ...state.risques,
            {
              ...risque,
              id: crypto.randomUUID(),
              dateIdentification: new Date().toISOString(),
              dateMiseAJour: new Date().toISOString(),
            },
          ],
        }));
      },

      updateRisque: (risqueId, updates) => {
        set((state) => ({
          risques: state.risques.map(r =>
            r.id === risqueId
              ? { ...r, ...updates, dateMiseAJour: new Date().toISOString() }
              : r
          ),
        }));
      },

      deleteRisque: (risqueId) => {
        set((state) => ({
          risques: state.risques.filter(r => r.id !== risqueId),
        }));
      },

      addCommentaire: (commentaire) => {
        set((state) => ({
          commentaires: {
            ...state.commentaires,
            [commentaire.projetId]: [
              ...(state.commentaires[commentaire.projetId] || []),
              {
                ...commentaire,
                id: crypto.randomUUID(),
                date: new Date().toISOString(),
                reponses: [],
              },
            ],
          },
        }));
      },

      addReponse: (commentaireId, reponse) => {
        set((state) => ({
          commentaires: Object.fromEntries(
            Object.entries(state.commentaires).map(([projetId, commentaires]) => [
              projetId,
              commentaires.map(c =>
                c.id === commentaireId
                  ? {
                      ...c,
                      reponses: [
                        ...c.reponses,
                        {
                          ...reponse,
                          id: crypto.randomUUID(),
                          date: new Date().toISOString(),
                          reponses: [],
                        },
                      ],
                    }
                  : c
              ),
            ])
          ),
        }));
      },

      deleteCommentaire: (commentaireId) => {
        set((state) => ({
          commentaires: Object.fromEntries(
            Object.entries(state.commentaires).map(([projetId, commentaires]) => [
              projetId,
              commentaires.filter(c => c.id !== commentaireId),
            ])
          ),
        }));
      },

      addReunion: (reunion) => {
        set((state) => ({
          reunions: [
            ...state.reunions,
            {
              ...reunion,
              id: crypto.randomUUID(),
            },
          ],
        }));
      },

      updateReunion: (reunionId, updates) => {
        set((state) => ({
          reunions: state.reunions.map(r =>
            r.id === reunionId ? { ...r, ...updates } : r
          ),
        }));
      },

      deleteReunion: (reunionId) => {
        set((state) => ({
          reunions: state.reunions.filter(r => r.id !== reunionId),
        }));
      },
    }),
    {
      name: 'dashboard-storage',
      partialize: (state) => ({
        configs: state.configs,
        notifications: state.notifications,
        risques: state.risques,
        commentaires: state.commentaires,
        reunions: state.reunions,
      }),
    }
  )
);