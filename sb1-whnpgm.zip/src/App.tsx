import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './components/Layout';
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { DashboardPage } from './pages/DashboardPage';
import { ObjectifsPage } from './pages/ObjectifsPage';
import { NouveauProjet } from './pages/projet/NouveauProjet';
import { ModifierProjet } from './pages/projet/ModifierProjet';
import { DetailProjet } from './pages/projet/DetailProjet';
import { GestionUtilisateurs } from './pages/admin/GestionUtilisateurs';
import { GestionProjetsAdmin } from './pages/admin/GestionProjetsAdmin';
import { ManuelUtilisateur } from './pages/aide/ManuelUtilisateur';
import { PreferencesPage } from './pages/PreferencesPage';
import { PrivateRoute } from './components/auth/PrivateRoute';
import { AdminRoute } from './components/auth/AdminRoute';
import { NotificationsProvider } from './components/notifications/NotificationsProvider';
import { LandingPage } from './pages/LandingPage';

function App() {
  return (
    <NotificationsProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route element={<PrivateRoute><Layout /></PrivateRoute>}>
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="objectifs" element={<ObjectifsPage />} />
            <Route path="aide" element={<ManuelUtilisateur />} />
            <Route path="preferences" element={<PreferencesPage />} />
            <Route path="projets">
              <Route path="nouveau" element={<NouveauProjet />} />
              <Route path=":id" element={<DetailProjet />} />
              <Route path=":id/modifier" element={<ModifierProjet />} />
            </Route>
            <Route path="admin">
              <Route path="utilisateurs" element={
                <AdminRoute>
                  <GestionUtilisateurs />
                </AdminRoute>
              } />
              <Route path="projets" element={
                <AdminRoute>
                  <GestionProjetsAdmin />
                </AdminRoute>
              } />
            </Route>
          </Route>
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </BrowserRouter>
    </NotificationsProvider>
  );
}

export default App;