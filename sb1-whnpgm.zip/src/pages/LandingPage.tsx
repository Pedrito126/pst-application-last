import React from 'react';
import { Link } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { 
  BarChart3, 
  Target, 
  Users, 
  Clock, 
  Shield, 
  FileText,
  ArrowRight,
  Building2,
  PlayCircle,
  BookOpen
} from 'lucide-react';

export function LandingPage() {
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);

  const features = [
    {
      icon: <BarChart3 className="h-6 w-6" />,
      title: "Tableau de bord intuitif",
      description: "Visualisez l'avancement de vos projets en un coup d'œil"
    },
    {
      icon: <Target className="h-6 w-6" />,
      title: "Objectifs stratégiques",
      description: "Alignez vos projets avec les objectifs de développement durable"
    },
    {
      icon: <Users className="h-6 w-6" />,
      title: "Collaboration efficace",
      description: "Travaillez en équipe sur les projets de manière transparente"
    },
    {
      icon: <Clock className="h-6 w-6" />,
      title: "Suivi en temps réel",
      description: "Restez informé de l'évolution de chaque projet"
    },
    {
      icon: <Shield className="h-6 w-6" />,
      title: "Sécurité avancée",
      description: "Vos données sont protégées selon les normes les plus strictes"
    },
    {
      icon: <FileText className="h-6 w-6" />,
      title: "Documentation complète",
      description: "Accédez à une documentation détaillée et à jour"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1B4332] to-[#9B2242]">
      <header className="bg-transparent">
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <Building2 className="h-8 w-8 text-white" />
              <span className="ml-2 text-xl font-bold text-white">Commune d'Ittre</span>
            </div>
            <div>
              {isAuthenticated ? (
                <Link
                  to="/dashboard"
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-[#1B4332] bg-white hover:bg-gray-50"
                >
                  Accéder au tableau de bord
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              ) : (
                <div className="space-x-4">
                  <Link
                    to="/login"
                    className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-[#1B4332] bg-white hover:bg-gray-50"
                  >
                    Connexion
                  </Link>
                  <Link
                    to="/register"
                    className="inline-flex items-center px-4 py-2 border border-white text-sm font-medium rounded-md text-white hover:bg-white/10"
                  >
                    Inscription
                  </Link>
                </div>
              )}
            </div>
          </div>
        </nav>
      </header>

      <main>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-24">
          <div className="text-center">
            <h1 className="text-4xl tracking-tight font-extrabold text-white sm:text-5xl md:text-6xl">
              Plan Stratégique Transversal
            </h1>
            <p className="mt-3 max-w-md mx-auto text-base text-gray-100 sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
              Une plateforme moderne pour la gestion et le suivi des projets stratégiques de la commune d'Ittre
            </p>
            <div className="mt-10 flex flex-col sm:flex-row justify-center gap-4">
              {!isAuthenticated ? (
                <>
                  <Link
                    to="/register"
                    className="inline-flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-[#1B4332] bg-white hover:bg-gray-50 md:text-lg"
                  >
                    Commencer maintenant
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                  <Link
                    to="/aide"
                    className="inline-flex items-center justify-center px-8 py-3 border border-white text-base font-medium rounded-md text-white hover:bg-white/10 md:text-lg"
                  >
                    Voir la documentation
                    <BookOpen className="ml-2 h-5 w-5" />
                  </Link>
                </>
              ) : (
                <>
                  <Link
                    to="/dashboard"
                    className="inline-flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-[#1B4332] bg-white hover:bg-gray-50 md:text-lg"
                  >
                    Accéder au tableau de bord
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                  <Link
                    to="/projets/nouveau"
                    className="inline-flex items-center justify-center px-8 py-3 border border-white text-base font-medium rounded-md text-white hover:bg-white/10 md:text-lg"
                  >
                    Créer un nouveau projet
                    <PlayCircle className="ml-2 h-5 w-5" />
                  </Link>
                </>
              )}
            </div>
          </div>

          <div className="mt-32">
            <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
              {features.map((feature, index) => (
                <div
                  key={index}
                  className="relative group bg-white/10 backdrop-blur-lg rounded-lg p-6 hover:bg-white/20 transition-all duration-300"
                >
                  <div className="absolute -inset-1 bg-gradient-to-r from-[#1B4332] to-[#9B2242] rounded-lg opacity-25 group-hover:opacity-100 transition-opacity duration-300 blur"></div>
                  <div className="relative">
                    <div className="h-12 w-12 rounded-lg bg-white/20 flex items-center justify-center text-white">
                      {feature.icon}
                    </div>
                    <h3 className="mt-4 text-xl font-semibold text-white">
                      {feature.title}
                    </h3>
                    <p className="mt-2 text-gray-100">
                      {feature.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>

      <footer className="bg-[#1B4332]">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
          <p className="text-center text-base text-gray-100">
            © {new Date().getFullYear()} Commune d'Ittre. Tous droits réservés.
          </p>
        </div>
      </footer>
    </div>
  );
}