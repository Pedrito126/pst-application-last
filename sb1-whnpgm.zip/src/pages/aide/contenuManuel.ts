export const contenuManuel = [
  {
    id: 'introduction',
    title: 'Introduction',
    content: `Bienvenue dans le manuel utilisateur de l'application de gestion du Plan Stratégique Transversal (PST) version 1.1.

Cette application vous permet de :
- Gérer et suivre les projets du PST
- Organiser les objectifs stratégiques et opérationnels
- Collaborer avec les différents services
- Suivre les budgets et les subsides
- Gérer les risques et les échéances

Configuration requise :
- Navigateur web récent (Chrome, Firefox, Edge)
- Résolution d'écran minimale : 1024x768`,
    image: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'tableau-bord',
    title: 'Tableau de bord personnalisable',
    content: `Le tableau de bord est votre interface principale, entièrement personnalisable selon vos besoins.

Widgets disponibles :
1. Projets récents
2. Favoris
3. Alertes
4. Statistiques
5. Calendrier
6. Budget
7. Risques
8. Notifications

Pour personnaliser votre tableau de bord :
1. Cliquez sur "Configurer" en haut à droite
2. Cochez/décochez les widgets souhaités
3. Réorganisez-les par glisser-déposer
4. Enregistrez vos préférences`,
    subsections: [
      {
        id: 'widgets',
        title: 'Configuration des widgets',
        content: `Chaque widget peut être :
- Activé/désactivé
- Déplacé
- Redimensionné
- Configuré individuellement

Les préférences sont sauvegardées automatiquement pour chaque utilisateur.`,
        image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1200&q=80'
      }
    ]
  },
  {
    id: 'gestion-projets',
    title: 'Gestion des projets',
    content: `La gestion des projets est au cœur de l'application. Chaque projet peut être :
- Créé en brouillon
- Modifié
- Dupliqué
- Supprimé
- Lié à d'autres projets

États possibles d'un projet :
- Brouillon
- Non démarré
- En cours
- Terminé
- Bloqué`,
    subsections: [
      {
        id: 'creation-projet',
        title: 'Création d\'un projet',
        content: `Pour créer un nouveau projet :
1. Cliquez sur "Nouveau projet" dans la navigation
2. Remplissez les informations requises
3. Ajoutez des documents et annexes
4. Définissez les liens avec d'autres projets
5. Enregistrez en brouillon ou publiez directement

La référence du projet est générée automatiquement selon le format :
- VI (Volet Interne) ou VE (Volet Externe)
- Numéro d'objectif stratégique
- Numéro d'objectif opérationnel
- Numéro séquentiel`,
        image: 'https://images.unsplash.com/photo-1557804506-669a67965ba0?auto=format&fit=crop&w=1200&q=80'
      },
      {
        id: 'annexes',
        title: 'Gestion des annexes',
        content: `Les annexes peuvent être :
- Glissées-déposées directement
- Organisées en dossiers
- Catégorisées et taguées
- Prévisualisées
- Versionnées

Types de fichiers supportés :
- Images (PNG, JPG, GIF)
- Documents (PDF, DOC, DOCX)
- Liens externes`,
        image: 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?auto=format&fit=crop&w=1200&q=80'
      }
    ]
  },
  {
    id: 'objectifs',
    title: 'Gestion des objectifs',
    content: `Les objectifs sont organisés hiérarchiquement :
1. Objectifs Stratégiques (OS)
2. Objectifs Opérationnels (OO)

La codification est automatique :
- OS : OS.I.01 (Interne) ou OS.E.01 (Externe)
- OO : OS.I.01.OO.01`,
    subsections: [
      {
        id: 'creation-objectif',
        title: 'Création d\'objectifs',
        content: `Pour créer un nouvel objectif :
1. Choisissez le volet (Interne/Externe)
2. Cliquez sur "+" pour ajouter un OS
3. Ajoutez des OO sous chaque OS
4. Le code est généré automatiquement`,
        image: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=1200&q=80'
      }
    ]
  },
  {
    id: 'preferences',
    title: 'Préférences utilisateur',
    content: `Gérez vos préférences personnelles :
- Modification du mot de passe
- Configuration des services
- Personnalisation du tableau de bord
- Notifications

Accès : Cliquez sur "Préférences" dans le menu principal.`,
    image: 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?auto=format&fit=crop&w=1200&q=80'
  }
];