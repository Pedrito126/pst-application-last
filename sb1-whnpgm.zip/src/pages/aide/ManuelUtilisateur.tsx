import React, { useState, useEffect, useRef } from 'react';
import { Search, Download, Printer } from 'lucide-react';
import { contenuManuel } from './contenuManuel';
import { useReactToPrint } from 'react-to-print';
import { Document, Packer, Paragraph, HeadingLevel } from 'docx';
import { saveAs } from 'file-saver';

interface Section {
  id: string;
  title: string;
  content: string;
  subsections?: Section[];
}

export function ManuelUtilisateur() {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeSection, setActiveSection] = useState<string | null>(null);
  const [searchResults, setSearchResults] = useState<Section[]>([]);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (searchTerm.length > 2) {
      const results = searchInSections(contenuManuel, searchTerm.toLowerCase());
      setSearchResults(results);
    } else {
      setSearchResults([]);
    }
  }, [searchTerm]);

  useEffect(() => {
    if (activeSection) {
      const element = document.getElementById(activeSection);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }
  }, [activeSection]);

  const searchInSections = (sections: Section[], term: string): Section[] => {
    const results: Section[] = [];
    
    sections.forEach(section => {
      if (
        section.title.toLowerCase().includes(term) ||
        section.content.toLowerCase().includes(term)
      ) {
        results.push(section);
      }
      
      if (section.subsections) {
        results.push(...searchInSections(section.subsections, term));
      }
    });
    
    return results;
  };

  const handleSectionClick = (sectionId: string) => {
    setActiveSection(sectionId);
  };

  const handlePrint = useReactToPrint({
    content: () => contentRef.current,
  });

  const handleExportWord = async () => {
    const doc = new Document({
      sections: [{
        properties: {},
        children: contenuManuel.map(section => [
          new Paragraph({
            text: section.title,
            heading: HeadingLevel.HEADING_1,
          }),
          new Paragraph({
            text: section.content,
          }),
          ...(section.subsections?.map(subsection => [
            new Paragraph({
              text: subsection.title,
              heading: HeadingLevel.HEADING_2,
            }),
            new Paragraph({
              text: subsection.content,
            }),
          ]).flat() || [])
        ]).flat()
      }]
    });

    const blob = await Packer.toBlob(doc);
    saveAs(blob, 'manuel-utilisateur-pst.docx');
  };

  const renderTableOfContents = (sections: Section[], level = 0) => (
    <ul className={`space-y-1 ${level > 0 ? 'ml-4' : ''}`}>
      {sections.map((section) => (
        <li key={section.id}>
          <button
            onClick={() => handleSectionClick(section.id)}
            className={`text-left hover:text-[#1B4332] ${
              activeSection === section.id ? 'font-bold text-[#1B4332]' : ''
            }`}
          >
            {section.title}
          </button>
          {section.subsections && renderTableOfContents(section.subsections, level + 1)}
        </li>
      ))}
    </ul>
  );

  const renderContent = (sections: Section[]) => (
    <div className="space-y-8">
      {sections.map((section) => (
        <div key={section.id} id={section.id} className="scroll-mt-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">{section.title}</h2>
          <div className="prose prose-blue max-w-none">
            {section.content.split('\n').map((paragraph, index) => (
              <p key={index} className="mb-4">{paragraph}</p>
            ))}
          </div>
          {section.subsections && renderContent(section.subsections)}
        </div>
      ))}
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Manuel Utilisateur</h1>
        <div className="flex items-center space-x-4">
          <div className="relative w-96">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Rechercher dans le manuel..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-[#1B4332] focus:border-[#1B4332]"
            />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
          </div>
          <button
            onClick={handlePrint}
            className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
          >
            <Printer className="h-5 w-5 mr-2" />
            Imprimer
          </button>
          <button
            onClick={handleExportWord}
            className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
          >
            <Download className="h-5 w-5 mr-2" />
            Exporter en Word
          </button>
        </div>
      </div>

      {searchTerm.length > 2 && searchResults.length > 0 ? (
        <div className="bg-white shadow rounded-lg p-6">
          <h2 className="text-lg font-medium mb-4">Résultats de recherche</h2>
          {renderContent(searchResults)}
        </div>
      ) : (
        <div className="grid grid-cols-4 gap-8">
          <div className="col-span-1 bg-white shadow rounded-lg p-6">
            <h2 className="text-lg font-medium mb-4">Table des matières</h2>
            {renderTableOfContents(contenuManuel)}
          </div>
          <div className="col-span-3 bg-white shadow rounded-lg p-6" ref={contentRef}>
            {renderContent(contenuManuel)}
          </div>
        </div>
      )}
    </div>
  );
}