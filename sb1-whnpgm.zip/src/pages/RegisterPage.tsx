import React from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { RegisterForm } from '../components/auth/RegisterForm';
import { useNotifications } from '../components/notifications/NotificationsProvider';

export function RegisterPage() {
  const navigate = useNavigate();
  const register = useAuthStore((state) => state.register);
  const { addNotification } = useNotifications();

  const handleRegister = async (data: {
    email: string;
    password: string;
    name: string;
  }) => {
    try {
      const success = await register(data);
      if (success) {
        addNotification('success', 'Compte créé avec succès');
        navigate('/login');
        return true;
      } else {
        addNotification('error', 'Cet email est déjà utilisé');
        return false;
      }
    } catch (error) {
      addNotification('error', 'Une erreur est survenue lors de la création du compte');
      return false;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
          Créer un compte
        </h2>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
          <RegisterForm onSuccess={handleRegister} />
          
          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-gray-500">
                  Déjà inscrit ?
                </span>
              </div>
            </div>

            <div className="mt-6">
              <Link
                to="/login"
                className="w-full flex justify-center py-2 px-4 border border-[#1B4332] rounded-md shadow-sm text-sm font-medium text-[#1B4332] bg-white hover:bg-[#1B4332] hover:text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#1B4332]"
              >
                Se connecter
              </Link>
            </div>
          </div>
        </div>
      </div>

      <footer className="mt-8 text-center text-sm text-gray-600">
        Proudly propulsed by Pedro Sevilla - GestionPST 2024
      </footer>
    </div>
  );
}