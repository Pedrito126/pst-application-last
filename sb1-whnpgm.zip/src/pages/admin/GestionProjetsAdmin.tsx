import React, { useState } from 'react';
import { useProjetStore } from '../../store/projetStore';
import { Trash2, Printer } from 'lucide-react';
import { formatDate } from '../../utils/formatters';
import { useReactToPrint } from 'react-to-print';
import { TestDataManager } from '../../components/admin/TestDataManager';
import { ExportBackup } from '../../components/admin/ExportBackup';

export function GestionProjetsAdmin() {
  const [selectedProjets, setSelectedProjets] = useState<string[]>([]);
  const { projets, supprimerProjet } = useProjetStore();
  const componentRef = React.useRef(null);

  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
  });

  const getEtatColor = (etat: string) => {
    switch (etat) {
      case 'NON_DEMARRE': return 'bg-blue-100 border-blue-500';
      case 'EN_COURS': return 'bg-orange-100 border-orange-500';
      case 'TERMINE': return 'bg-green-100 border-green-500';
      case 'BLOQUE': return 'bg-red-100 border-red-500';
      default: return 'bg-gray-100 border-gray-500';
    }
  };

  const handleSelectProjet = (id: string) => {
    setSelectedProjets(prev => 
      prev.includes(id) 
        ? prev.filter(p => p !== id)
        : [...prev, id]
    );
  };

  const handleDeleteSelected = () => {
    if (window.confirm(`Voulez-vous vraiment supprimer ${selectedProjets.length} projet(s) ?`)) {
      selectedProjets.forEach(id => supprimerProjet(id));
      setSelectedProjets([]);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">
          Gestion des Projets
        </h1>
        <div className="flex space-x-4">
          <button
            onClick={handlePrint}
            className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
          >
            <Printer className="h-5 w-5 mr-2" />
            Imprimer
          </button>
          {selectedProjets.length > 0 && (
            <button
              onClick={handleDeleteSelected}
              className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700"
            >
              <Trash2 className="h-5 w-5 mr-2" />
              Supprimer ({selectedProjets.length})
            </button>
          )}
        </div>
      </div>

      <TestDataManager />
      <ExportBackup />

      <div ref={componentRef} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {projets.map((projet) => (
          <div
            key={projet.id}
            className={`relative p-4 rounded-lg border-l-4 ${
              getEtatColor(projet.etat)
            } ${
              selectedProjets.includes(projet.id) ? 'ring-2 ring-[#1B4332]' : ''
            }`}
          >
            <div className="flex justify-between items-start">
              <h3 className="text-sm font-medium text-gray-900">
                {projet.titre}
              </h3>
              <input
                type="checkbox"
                checked={selectedProjets.includes(projet.id)}
                onChange={() => handleSelectProjet(projet.id)}
                className="h-4 w-4 text-[#1B4332] border-gray-300 rounded focus:ring-[#1B4332] print:hidden"
              />
            </div>
            <p className="mt-1 text-sm text-gray-600">
              {projet.reference}
            </p>
            <div className="mt-2 grid grid-cols-2 gap-2 text-xs text-gray-500">
              <div>
                <span className="font-medium">État:</span> {projet.etat.replace('_', ' ')}
              </div>
              <div>
                <span className="font-medium">Priorité:</span> {projet.priorite}
              </div>
              <div>
                <span className="font-medium">Budget:</span> {projet.budgetActualise}€
              </div>
              <div>
                <span className="font-medium">Mise à jour:</span> {formatDate(projet.dateMiseAJour)}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}