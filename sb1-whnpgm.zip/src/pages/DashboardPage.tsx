import React from 'react';
import { useAuthStore } from '../store/authStore';
import { ListeProjets } from '../components/projet/ListeProjets';
import { FiltresAvances } from '../components/projet/FiltresAvances';
import { StatistiquesDashboard } from '../components/stats/StatistiquesDashboard';
import { StatistiquesFinancieres } from '../components/stats/StatistiquesFinancieres';
import { ExportPDF } from '../components/projet/ExportPDF';
import { RapportIA } from '../components/rapport/RapportIA';

export function DashboardPage() {
  const user = useAuthStore((state) => state.user);
  const isFinancialUser = user?.role === 'DF';
  const canViewAIReport = ['ADMIN', 'DG', 'DF'].includes(user?.role || '');

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-900">Tableau de bord</h1>
        <ExportPDF />
      </div>

      {isFinancialUser ? (
        <StatistiquesFinancieres />
      ) : (
        <StatistiquesDashboard />
      )}
      
      {canViewAIReport && <RapportIA />}
      
      <FiltresAvances />
      <ListeProjets />
    </div>
  );
}