import React from 'react';

export function DashboardPage() {
  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <h1 className="text-3xl font-bold text-gray-900">
        Tableau de bord
      </h1>
      <p className="mt-4 text-xl text-gray-600">
        Bienvenue sur votre tableau de bord.
      </p>
    </div>
  );
}