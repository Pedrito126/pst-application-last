import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useAuthStore } from '../store/authStore';
import { useNotifications } from '../components/notifications/NotificationsProvider';
import { Settings, Lock, Building } from 'lucide-react';

const passwordSchema = z.object({
  currentPassword: z.string().min(1, 'Le mot de passe actuel est requis'),
  newPassword: z.string()
    .min(12, 'Le mot de passe doit contenir au moins 12 caractères')
    .regex(
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{12,}$/,
      'Le mot de passe doit contenir au moins une majuscule, une minuscule, un chiffre et un caractère spécial'
    ),
  confirmPassword: z.string()
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "Les mots de passe ne correspondent pas",
  path: ["confirmPassword"],
});

const servicesSchema = z.object({
  services: z.array(z.string()).min(1, 'Au moins un service doit être sélectionné')
});

const services = [
  'Direction générale',
  'Direction financière',
  'Service informatique',
  'Service technique',
  'Service urbanisme',
  'Service population',
  'Service social',
  'Service culturel',
  'Service jeunesse',
  'Service sports',
  'Service environnement',
  'Service mobilité',
  'Service travaux',
  'Service communication'
];

export function PreferencesPage() {
  const { user, updatePassword, updateServices } = useAuthStore();
  const { addNotification } = useNotifications();
  const [selectedServices, setSelectedServices] = useState<string[]>(user?.services || []);

  const {
    register: registerPassword,
    handleSubmit: handleSubmitPassword,
    formState: { errors: passwordErrors }
  } = useForm({
    resolver: zodResolver(passwordSchema)
  });

  const handlePasswordChange = async (data: any) => {
    try {
      await updatePassword(data.currentPassword, data.newPassword);
      addNotification('success', 'Mot de passe modifié avec succès');
    } catch (error) {
      addNotification('error', 'Erreur lors de la modification du mot de passe');
    }
  };

  const handleServicesChange = (service: string) => {
    setSelectedServices(prev => 
      prev.includes(service)
        ? prev.filter(s => s !== service)
        : [...prev, service]
    );
  };

  const handleSaveServices = () => {
    try {
      updateServices(selectedServices);
      addNotification('success', 'Services mis à jour avec succès');
    } catch (error) {
      addNotification('error', 'Erreur lors de la mise à jour des services');
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-gray-900 mb-8">Préférences</h1>

      <div className="space-y-8">
        {/* Modification du mot de passe */}
        <div className="bg-white shadow rounded-lg p-6">
          <h2 className="text-lg font-medium flex items-center mb-6">
            <Lock className="h-5 w-5 mr-2" />
            Modification du mot de passe
          </h2>

          <form onSubmit={handleSubmitPassword(handlePasswordChange)} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Mot de passe actuel
              </label>
              <input
                type="password"
                {...registerPassword('currentPassword')}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
              />
              {passwordErrors.currentPassword && (
                <p className="mt-1 text-sm text-red-600">
                  {passwordErrors.currentPassword.message}
                </p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Nouveau mot de passe
              </label>
              <input
                type="password"
                {...registerPassword('newPassword')}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
              />
              {passwordErrors.newPassword && (
                <p className="mt-1 text-sm text-red-600">
                  {passwordErrors.newPassword.message}
                </p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Confirmer le nouveau mot de passe
              </label>
              <input
                type="password"
                {...registerPassword('confirmPassword')}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#1B4332] focus:ring-[#1B4332]"
              />
              {passwordErrors.confirmPassword && (
                <p className="mt-1 text-sm text-red-600">
                  {passwordErrors.confirmPassword.message}
                </p>
              )}
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-[#1B4332] hover:bg-[#9B2242]"
              >
                Modifier le mot de passe
              </button>
            </div>
          </form>
        </div>

        {/* Gestion des services */}
        <div className="bg-white shadow rounded-lg p-6">
          <h2 className="text-lg font-medium flex items-center mb-6">
            <Building className="h-5 w-5 mr-2" />
            Services
          </h2>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              {services.map((service) => (
                <label key={service} className="flex items-center">
                  <input
                    type="checkbox"
                    checked={selectedServices.includes(service)}
                    onChange={() => handleServicesChange(service)}
                    className="rounded border-gray-300 text-[#1B4332] focus:ring-[#1B4332]"
                  />
                  <span className="ml-2 text-sm text-gray-700">{service}</span>
                </label>
              ))}
            </div>

            <div className="flex justify-end">
              <button
                onClick={handleSaveServices}
                className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-[#1B4332] hover:bg-[#9B2242]"
              >
                Enregistrer les services
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}