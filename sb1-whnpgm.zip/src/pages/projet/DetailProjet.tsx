import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useProjetStore } from '../../store/projetStore';
import { BadgeODD } from '../../components/odd/BadgeODD';
import { FileEdit, ArrowLeft, Download, Printer, History } from 'lucide-react';
import { formatDate, formatMontant } from '../../utils/formatters';
import { generateProjetPDF } from '../../utils/pdfGenerator';
import { useReactToPrint } from 'react-to-print';
import { GestionAnnexes } from '../../components/projet/GestionAnnexes';
import { ValidationFinanciere } from '../../components/projet/ValidationFinanciere';
import { LiaisonProjets } from '../../components/projet/LiaisonProjets';
import { HistoriqueVersions } from '../../components/projet/HistoriqueVersions';
import { useAuthStore } from '../../store/authStore';

export function DetailProjet() {
  const { id } = useParams<{ id: string }>();
  const [showHistorique, setShowHistorique] = useState(false);
  const projet = useProjetStore((state) => 
    state.projets.find(p => p.id === id)
  );
  const user = useAuthStore((state) => state.user);
  const componentRef = React.useRef(null);

  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
  });

  const handleExportPDF = () => {
    if (!projet) return;
    const doc = generateProjetPDF(projet);
    doc.save(`projet-${projet.reference}.pdf`);
  };

  if (!projet) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Projet non trouvé</p>
        <Link to="/dashboard" className="text-blue-600 hover:text-blue-800 mt-4 inline-block">
          Retour au tableau de bord
        </Link>
      </div>
    );
  }

  const getEtatColor = (etat: string) => {
    switch (etat) {
      case 'BROUILLON': return 'bg-gray-100 text-gray-800';
      case 'NON_DEMARRE': return 'bg-blue-100 text-blue-800';
      case 'EN_COURS': return 'bg-yellow-100 text-yellow-800';
      case 'TERMINE': return 'bg-green-100 text-green-800';
      case 'BLOQUE': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="flex justify-between items-center mb-6">
        <Link
          to="/dashboard"
          className="inline-flex items-center text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          Retour
        </Link>
        <div className="flex space-x-4">
          <button
            onClick={() => setShowHistorique(!showHistorique)}
            className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
          >
            <History className="h-5 w-5 mr-2" />
            Historique
          </button>
          <button
            onClick={handlePrint}
            className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
          >
            <Printer className="h-5 w-5 mr-2" />
            Imprimer
          </button>
          <button
            onClick={handleExportPDF}
            className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
          >
            <Download className="h-5 w-5 mr-2" />
            Exporter PDF
          </button>
          <Link
            to={`/projets/${id}/modifier`}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-[#1B4332] hover:bg-[#9B2242]"
          >
            <FileEdit className="h-5 w-5 mr-2" />
            Modifier
          </Link>
        </div>
      </div>

      {showHistorique ? (
        <HistoriqueVersions versions={projet.historique} />
      ) : (
        <div ref={componentRef} className="space-y-6">
          <div className="bg-white shadow rounded-lg">
            <div className="px-6 py-4 border-b border-gray-200">
              <div className="flex justify-between items-start">
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">{projet.titre}</h1>
                  <p className="mt-1 text-sm text-gray-500">Référence: {projet.reference}</p>
                </div>
                <div className="flex flex-col items-end">
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getEtatColor(projet.etat)}`}>
                    {projet.etat.replace('_', ' ')}
                  </span>
                  <span className="mt-1 text-sm text-gray-500">
                    Mis à jour le {formatDate(projet.dateMiseAJour)}
                  </span>
                </div>
              </div>
            </div>

            {/* ... (reste du contenu existant) ... */}
          </div>

          <div className="bg-white shadow rounded-lg p-6">
            <GestionAnnexes projetId={projet.id} />
          </div>

          <div className="bg-white shadow rounded-lg p-6">
            <LiaisonProjets projetId={projet.id} />
          </div>
        </div>
      )}
    </div>
  );
}