import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { FormulaireProjet } from '../../components/projet/FormulaireProjet';

export function ModifierProjet() {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();

  if (!id) {
    return <div>Erreur: ID du projet manquant</div>;
  }

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">
        Modifier la Fiche Projet
      </h1>
      
      <div className="bg-white shadow rounded-lg p-6">
        <FormulaireProjet 
          projetId={id}
          onSuccess={() => navigate('/dashboard')}
        />
      </div>
    </div>
  );
}