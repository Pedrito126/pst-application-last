import React from 'react';
import { useNavigate } from 'react-router-dom';
import { FormulaireProjet } from '../../components/projet/FormulaireProjet';

export function NouveauProjet() {
  const navigate = useNavigate();

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">
        Nouvelle Fiche Projet
      </h1>
      
      <div className="bg-white shadow rounded-lg p-6">
        <FormulaireProjet 
          onSuccess={() => navigate('/dashboard')}
        />
      </div>
    </div>
  );
}