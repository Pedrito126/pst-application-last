export const ODD = [
  {
    id: 1,
    titre: "Pas de pauvreté",
    description: "Éliminer la pauvreté sous toutes ses formes et partout dans le monde",
    couleur: "#E5243B"
  },
  {
    id: 2,
    titre: "Faim « zéro »",
    description: "Éliminer la faim, assurer la sécurité alimentaire, améliorer la nutrition et promouvoir l'agriculture durable",
    couleur: "#DDA63A"
  },
  {
    id: 3,
    titre: "Bonne santé et bien-être",
    description: "Permettre à tous de vivre en bonne santé et promouvoir le bien-être de tous à tout âge",
    couleur: "#4C9F38"
  },
  {
    id: 4,
    titre: "Éducation de qualité",
    description: "Assurer l'accès de tous à une éducation de qualité et promouvoir les possibilités d'apprentissage tout au long de la vie",
    couleur: "#C5192D"
  },
  {
    id: 5,
    titre: "Égalité entre les sexes",
    description: "Parvenir à l'égalité des sexes et autonomiser toutes les femmes et les filles",
    couleur: "#FF3A21"
  },
  {
    id: 6,
    titre: "Eau propre et assainissement",
    description: "Garantir l'accès de tous à l'eau et à l'assainissement et assurer une gestion durable des ressources en eau",
    couleur: "#26BDE2"
  },
  {
    id: 7,
    titre: "Énergie propre et d'un coût abordable",
    description: "Garantir l'accès de tous à des services énergétiques fiables, durables et modernes, à un coût abordable",
    couleur: "#FCC30B"
  },
  {
    id: 8,
    titre: "Travail décent et croissance économique",
    description: "Promouvoir une croissance économique soutenue, partagée et durable, le plein emploi productif et un travail décent pour tous",
    couleur: "#A21942"
  },
  {
    id: 9,
    titre: "Industrie, innovation et infrastructure",
    description: "Bâtir une infrastructure résiliente, promouvoir une industrialisation durable et encourager l'innovation",
    couleur: "#FD6925"
  },
  {
    id: 10,
    titre: "Inégalités réduites",
    description: "Réduire les inégalités dans les pays et d'un pays à l'autre",
    couleur: "#DD1367"
  },
  {
    id: 11,
    titre: "Villes et communautés durables",
    description: "Faire en sorte que les villes et les établissements humains soient ouverts à tous, sûrs, résilients et durables",
    couleur: "#FD9D24"
  },
  {
    id: 12,
    titre: "Consommation et production responsables",
    description: "Établir des modes de consommation et de production durables",
    couleur: "#BF8B2E"
  },
  {
    id: 13,
    titre: "Mesures relatives à la lutte contre les changements climatiques",
    description: "Prendre d'urgence des mesures pour lutter contre les changements climatiques et leurs répercussions",
    couleur: "#3F7E44"
  },
  {
    id: 14,
    titre: "Vie aquatique",
    description: "Conserver et exploiter de manière durable les océans, les mers et les ressources marines",
    couleur: "#0A97D9"
  },
  {
    id: 15,
    titre: "Vie terrestre",
    description: "Préserver et restaurer les écosystèmes terrestres, gérer durablement les forêts, lutter contre la désertification",
    couleur: "#56C02B"
  },
  {
    id: 16,
    titre: "Paix, justice et institutions efficaces",
    description: "Promouvoir l'avènement de sociétés pacifiques et ouvertes aux fins du développement durable",
    couleur: "#00689D"
  },
  {
    id: 17,
    titre: "Partenariats pour la réalisation des objectifs",
    description: "Renforcer les moyens de mettre en œuvre le Partenariat mondial pour le développement durable et le revitaliser",
    couleur: "#19486A"
  }
];