# Instructions de sauvegarde

1. Sauvegardez les fichiers sources :
   - Tout le contenu du dossier /src
   - Les fichiers de configuration (package.json, vite.config.ts, etc.)
   - Les assets dans /public

2. Exportez la base de données :
   - Utilisez la fonction d'export dans le panneau admin
   - Sauvegardez le fichier JSON généré
   - Conservez la structure des données

3. Documentation :
   - Exportez le manuel utilisateur
   - Conservez les instructions de déploiement
   - Gardez une copie des configurations

4. Vérification :
   - Testez la restauration dans un environnement propre
   - Validez l'intégrité des données
   - Vérifiez les dépendances

5. Sécurité :
   - Protégez les données sensibles
   - Cryptez les sauvegardes si nécessaire
   - Stockez dans un endroit sûr